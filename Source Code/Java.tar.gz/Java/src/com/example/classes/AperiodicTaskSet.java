package com.example.classes;

import java.util.Collections;

public class AperiodicTaskSet
{
	private static final int MAX_SIMULATION_TIME = 10000;

	public java.util.ArrayList<AperiodicTask> myTaskSet;
	public java.util.ArrayList<AperiodicTask> sortedMyTaskSet;
	public int numberOfTasks;
	public int algorithm;
	public String conditionString;
	public boolean isSchedulable;
	public int simulationTime;
	public String[] simulationScenario;
	public boolean[] deadlineMiss;
	public boolean[] preemption;
	public int numberOfMisses;
	public float missRate;
	public int numberOfPreemption;
	public float utilizationFactorOfProcessor;
	public int lastComputationTime;
	public int maximumLateness;
	public int maximumTardiness;
	public int maximumLaxity;
	public String infoString; 
	
	public AperiodicTaskSet(java.util.ArrayList<AperiodicTask> taskSet, int numberOfTasks, int algorithm)
	{
		this.myTaskSet = taskSet;
		for (int i = 0; i < myTaskSet.size(); i++)
		{
			this.myTaskSet.get(i).setpreviousPos(i);
		}
		this.sortedMyTaskSet = new java.util.ArrayList<AperiodicTask> (this.myTaskSet);
		Collections.sort(sortedMyTaskSet, AperiodicTask.absoluteDeadlineComparator);
		
		for (int i = 0; i < this.numberOfTasks; i++)
		{
			System.out.println(this.sortedMyTaskSet.get(i).getabsoluteDeadline());
		}
		
		this.numberOfTasks = numberOfTasks;
		this.algorithm = algorithm;
		this.conditionString = "";
		this.simulationTime = Collections.max(myTaskSet, AperiodicTask.computationTimeComparator).getcomputationTime() + Collections.max(myTaskSet, AperiodicTask.absoluteDeadlineComparator).getabsoluteDeadline();
		this.simulationScenario = new String[MAX_SIMULATION_TIME];
		this.deadlineMiss = new boolean[MAX_SIMULATION_TIME];
		this.preemption = new boolean[MAX_SIMULATION_TIME];
		for (int i = 0; i < MAX_SIMULATION_TIME; i++)
		{
			this.simulationScenario[i] = "idle";
			this.deadlineMiss[i] = this.preemption[i] = false;
		}
		this.numberOfMisses = this.numberOfPreemption = 0;
		this.missRate = 0;
		this.utilizationFactorOfProcessor = 0;
		this.lastComputationTime = 0;

		CheckSchedulability();
		ExecuteSimulation();
		SetExtraInfo();
	}

	public final void CheckSchedulability()
	{
		switch (this.algorithm)
		{
			case 0:
				this.isSchedulable = IsSchedulableByJacksonAlgorithm();
				break;
			case 1:
				this.isSchedulable = IsSchedulableByHornAlgorithm();
				break;
		}
	}

	public final boolean IsSchedulableByJacksonAlgorithm()
	{

		boolean localIsSchedulable = true;
		int lhs;

		for (int i = 0; i < this.numberOfTasks; i++)
		{
			lhs = 0;
			this.conditionString += "Checking Schedulability For Task <" + this.sortedMyTaskSet.get(i).getname() + ">: ";

			for (int j = 0; j <= i; j++)
			{
				if (j == 0)
				{
					this.conditionString += this.sortedMyTaskSet.get(j).getcomputationTime() + " ";
				}
				else
				{
					this.conditionString += "+ " + this.sortedMyTaskSet.get(j).getcomputationTime() + " ";
				}

				lhs += this.sortedMyTaskSet.get(j).getcomputationTime();
			}

			if (this.numberOfTasks != 1 && i != 0)
			{
				this.conditionString += " = " + lhs;
			}
			this.conditionString += " <= " + this.sortedMyTaskSet.get(i).getabsoluteDeadline() + "\t";
			if (lhs <= sortedMyTaskSet.get(i).getabsoluteDeadline())
			{
				conditionString += "True";
			}
			else
			{
				conditionString += "False";
				localIsSchedulable = false;
			}

			this.conditionString += "\n";
		}
		if (localIsSchedulable)
		{
			this.conditionString += "\n" + "TaskSet is schedulable by Jackson algorithm.";
		}
		else
		{
			this.conditionString += "\n" + "TaskSet isn't schedulable by Jackson algorithm.";
		}

		return localIsSchedulable;
	}

	public final boolean IsSchedulableByHornAlgorithm()
	{

		java.util.ArrayList<AperiodicTask> sortedTasksCopy = this.sortedMyTaskSet;
		boolean localIsSchedulable = true;
		int f0 = 0;
		int maximumReleaseTime = 0;

		for (int i = 0; i < sortedTasksCopy.size(); i++)
		{
			if (sortedTasksCopy.get(i).getreleaseTime() > maximumReleaseTime)
			{
				maximumReleaseTime = sortedTasksCopy.get(i).getreleaseTime();
			}
		}

		for (int t = 0; t <= maximumReleaseTime; t++)
		{
			f0 = f0 > t ? f0 : t;
			for (int i = 0; i < sortedTasksCopy.size(); i++)
			{
				if (t == sortedTasksCopy.get(i).getreleaseTime())
				{
					this.conditionString += "Checking Schedulability For Task <" + sortedTasksCopy.get(i).getname() + ">: ";
					this.conditionString += f0 + " + " + sortedTasksCopy.get(i).getcomputationTime() + " = " + (f0 + sortedTasksCopy.get(i).getcomputationTime()) + " <= " + sortedTasksCopy.get(i).getabsoluteDeadline() + "\t";
					if (f0 + sortedTasksCopy.get(i).getcomputationTime() <= sortedTasksCopy.get(i).getabsoluteDeadline())
					{
						this.conditionString += "True" + "\n";
					}
					else
					{
						this.conditionString += "False" + "\n";
						localIsSchedulable = false;
					}
					f0 += sortedTasksCopy.get(i).getcomputationTime();
				}
			}
		}

		if (localIsSchedulable)
		{
			this.conditionString += "TaskSet is Schedulable by Horn Algorithm." + "\n";
		}
		else
		{
			this.conditionString += "We can not guarantee schedulability of this task set by Horn Algorithm" + "\n";
		}

		return localIsSchedulable;
	}

	public final void ExecuteSimulation()
	{
		switch (this.algorithm)
		{
			case 0:
				ExecuteSimulationByJacksonAlgorithm();
				break;
			case 1:
				ExecuteSimulationByHornAlgorithm();
				break;
		}
	}

	public final void ExecuteSimulationByJacksonAlgorithm()
	{

		for (int t = 0; t < this.simulationTime; t++)
		{
			if (this.sortedMyTaskSet.isEmpty())
			{
				break;
			}
			if (this.sortedMyTaskSet.get(0).HasNeedToExecute())
			{
				this.sortedMyTaskSet.get(0).ExecuteOneCycle();
				this.simulationScenario[t] = this.sortedMyTaskSet.get(0).getname();
			}

			for (AperiodicTask i : sortedMyTaskSet)
			{
				if (i.MissedDeadline(t + 1))
				{
					this.deadlineMiss[t + 1] = true;
				}
			}

			if (!this.sortedMyTaskSet.get(0).HasNeedToExecute())
			{
				this.myTaskSet.get(this.sortedMyTaskSet.get(0).getpreviousPos()).setfinishingTime(t + 1);
				this.sortedMyTaskSet.remove(0);
			}
		}
	}

	public final void ExecuteSimulationByHornAlgorithm()
	{
		int index;
		boolean flag = false;
		int virtualNumberOfTasks = this.numberOfTasks;

		for (int t = 0; t < this.simulationTime; t++)
		{
			if (this.sortedMyTaskSet.isEmpty())
			{
				break;
			}
			index = 0;
			while (index < virtualNumberOfTasks && t < this.sortedMyTaskSet.get(index).getreleaseTime())
			{
				index++;
			}

			if (index == virtualNumberOfTasks)
			{
				continue;
			}


			for (AperiodicTask i : sortedMyTaskSet)
			{
				if (i.MissedDeadline(t))
				{
					this.deadlineMiss[t] = true;
				}
			}

			if (this.sortedMyTaskSet.get(index).HasNeedToExecute())
			{
				this.sortedMyTaskSet.get(index).ExecuteOneCycle();
				this.simulationScenario[t] = this.sortedMyTaskSet.get(index).getname();
			}

			for (AperiodicTask i : sortedMyTaskSet)
			{
				if (i.MissedDeadline(t + 1))
				{
					this.deadlineMiss[t + 1] = true;
				}
			}

			if (t != 0)
			{
				if (!flag && !this.simulationScenario[t].equals(this.simulationScenario[t - 1]) && !this.simulationScenario[t - 1].equals("idle"))
				{
					preemption[t] = true;
				}
			}

			flag = false;
			if (!this.sortedMyTaskSet.get(index).HasNeedToExecute())
			{
				flag = true;
				this.myTaskSet.get(this.sortedMyTaskSet.get(index).getpreviousPos()).setfinishingTime(t + 1);
				this.sortedMyTaskSet.remove(index);
				virtualNumberOfTasks--;
			}
		}
	}

	public final void SetExtraInfo()
	{
		int u = 0;
		for (int i = MAX_SIMULATION_TIME - 1; i >= 0; i--)
		{
			if (!this.simulationScenario[i].equals("idle"))
			{
				this.lastComputationTime = i;
				break;
			}
		}

		for (int i = 0; i <= this.lastComputationTime; i++)
		{
			if (!simulationScenario[i].equals("idle"))
			{
				u++;
			}
		}

		this.utilizationFactorOfProcessor = (float)u / (lastComputationTime + 1);

		for (int i = 0; i <= this.lastComputationTime; i++)
		{
			if (this.deadlineMiss[i])
			{
				this.numberOfMisses++;
			}
		}

		for (int i = 0; i <= this.lastComputationTime; i++)
		{
			if (this.preemption[i])
			{
				this.numberOfPreemption++;
			}
		}

		this.missRate = (float)this.numberOfMisses / this.numberOfTasks;


		this.maximumLateness = this.myTaskSet.get(0).getfinishingTime() - this.myTaskSet.get(0).getabsoluteDeadline();
		for (int i = 0; i < this.myTaskSet.size(); i++)
		{
			if (this.myTaskSet.get(i).getfinishingTime() - this.myTaskSet.get(i).getabsoluteDeadline() > this.maximumLateness)
			{
				this.maximumLateness = this.myTaskSet.get(i).getfinishingTime() - this.myTaskSet.get(i).getabsoluteDeadline();
			}
		}


		this.maximumTardiness = this.maximumLateness > 0 ? this.maximumLateness : 0;


		this.maximumLaxity = this.myTaskSet.get(0).getabsoluteDeadline() - this.myTaskSet.get(0).getreleaseTime() - this.myTaskSet.get(0).getcomputationTime();
		for (int i = 0; i < this.myTaskSet.size(); i++)
		{
			if (this.myTaskSet.get(i).getabsoluteDeadline() - this.myTaskSet.get(i).getreleaseTime() - this.myTaskSet.get(i).getcomputationTime() > this.maximumLaxity)
			{
				this.maximumLaxity = this.myTaskSet.get(i).getabsoluteDeadline() - this.myTaskSet.get(i).getreleaseTime() - this.myTaskSet.get(i).getcomputationTime();
			}
		}

        this.infoString = "";
        this.infoString += "Utilization Factor Of Processor = " + this.utilizationFactorOfProcessor + "\n";
        this.infoString += "Number Of Misses = " + this.numberOfMisses + "\n";
        this.infoString += "Miss Rate = " + this.missRate + "\n";
        this.infoString += "Number Of Preemption = " + this.numberOfPreemption + "\n";
        this.infoString += "Maximum Lateness = " + this.maximumLateness + "\n";
        this.infoString += "Maximum Tardiness = " + this.maximumTardiness + "\n";
        this.infoString += "Maximum Laxity = " + this.maximumLaxity + "\n";
		
	}

	public final void PrintTaskSetInfo()
	{
		for (AperiodicTask i : this.sortedMyTaskSet)
		{
			System.out.println(i.getname() + "\t" + i.getabsoluteDeadline());
		}
		System.out.println("Conditions:\n" + this.conditionString);
		System.out.println("Simulation Time:\t" + this.simulationTime);
		for (int i = 0; i < this.simulationTime; i++)
		{
			System.out.println(i + "\t" + this.simulationScenario[i] + "\t" + this.deadlineMiss[i] + "\t" + this.preemption[i]);
		}
		System.out.println("Utilizitaion Factor = " + this.utilizationFactorOfProcessor);
		System.out.println("Number Of Deadline Misses = " + this.numberOfMisses);
		System.out.println("Miss Rate = " + this.missRate);
		System.out.println("Number of Preemptions = " + this.numberOfPreemption);
		System.out.println("Maximum Lateness = " + this.maximumLateness);
		System.out.println("Maximum Tardiness = " + this.maximumTardiness);
		System.out.println("Maximum Laxity = " + this.maximumLaxity);
		System.out.println("Finishing Times: ");
		for (int i = 0; i < this.myTaskSet.size(); i++)
		{
			System.out.println(this.myTaskSet.get(i).getname() + "\t" + this.myTaskSet.get(i).getfinishingTime());
		}
	}

}