package com.example.classes;

import java.util.ArrayList;
import java.util.List;

public class TaskSet {
	public List<Task>  tasks=new ArrayList<Task>();
	public float GetU(){
		float result = 0;
		for(Task t: tasks)
			result+=t.GetU();

		return result;
	}
	public int GetHyperperiodTime(){
		return 100;
	}
}
