package com.example.classes;

import java.util.Comparator;
import java.util.Random;

import android.graphics.Color;

public class AperiodicTask implements Cloneable
{
	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}
	public int color;
	private String name;
	public final String getname()
	{
		return name;
	}
	public final void setname(String value)
	{
		name = value;
	}
	private int releaseTime;
	public final int getreleaseTime()
	{
		return releaseTime;
	}
	public final void setreleaseTime(int value)
	{
		releaseTime = value;
	}
	private int computationTime;
	public final int getcomputationTime()
	{
		return computationTime;
	}
	public final void setcomputationTime(int value)
	{
		computationTime = value;
	}
	private int absoluteDeadline;
	public final int getabsoluteDeadline()
	{
		return absoluteDeadline;
	}
	public final void setabsoluteDeadline(int value)
	{
		absoluteDeadline = value;
	}
	private int remainingTimeOfExecution;
	public final int getremainingTimeOfExecution()
	{
		return remainingTimeOfExecution;
	}
	public final void setremainingTimeOfExecution(int value)
	{
		remainingTimeOfExecution = value;
	}
	private int finishingTime;
	public final int getfinishingTime()
	{
		return finishingTime;
	}
	public final void setfinishingTime(int value)
	{
		finishingTime = value;
	}
	private int previousPos;
	public final int getpreviousPos()
	{
		return previousPos;
	}
	public final void setpreviousPos(int value)
	{
		previousPos = value;
	}
	
	public static Comparator<AperiodicTask> absoluteDeadlineComparator = new Comparator<AperiodicTask>()
	{
		public int compare (AperiodicTask t1, AperiodicTask t2)
		{
			int absoluteDeadline1 = t1.getabsoluteDeadline();
			int absoluteDeadline2 = t2.getabsoluteDeadline();
			return absoluteDeadline1 - absoluteDeadline2;
		}
	};
	
	public static Comparator<AperiodicTask> releaseTimeComparator = new Comparator<AperiodicTask>()
	{
		public int compare (AperiodicTask t1, AperiodicTask t2)
		{
			int releaseTime1 = t1.releaseTime;
			int releaseTime2 = t2.releaseTime;
			return releaseTime1 - releaseTime2;
		}
	};
	
	public static Comparator<AperiodicTask> computationTimeComparator = new Comparator<AperiodicTask>()
			{
				public int compare (AperiodicTask t1, AperiodicTask t2)
				{
					int computationTime1 = t1.getcomputationTime();
					int computationTime2 = t2.getcomputationTime();
					return computationTime1 - computationTime2;
				}
			};

	public AperiodicTask(String name, int releaseTime, int computationTime, int absoluteDeadline)
	{
		color = Color.rgb(new Random().nextInt(150)+106, new Random().nextInt(150)+106, new Random().nextInt(150)+106);
		this.setname(name);
		this.setreleaseTime(releaseTime);
		this.setcomputationTime(computationTime);
		this.setabsoluteDeadline(absoluteDeadline);
		this.setremainingTimeOfExecution(this.getcomputationTime());
	}

	public final void ExecuteOneCycle()
	{
		this.setremainingTimeOfExecution(this.getremainingTimeOfExecution() - 1);
	}

	public final boolean HasNeedToExecute()
	{
		return (this.getremainingTimeOfExecution() > 0);
	}

	public final boolean IsReleased(int t)
	{
		return (t >= this.getreleaseTime());
	}

	public final boolean MissedDeadline(int t)
	{
		if (t == this.getabsoluteDeadline() && this.HasNeedToExecute())
		{
			return true;
		}
		return false;
	}

	public final void PrintTaskInfo()
	{
		System.out.println("Task Name: " + this.getname());
		System.out.println("Release Time: " + this.getreleaseTime());
		System.out.println("Computation Time: " + this.getcomputationTime());
		System.out.println("Absolute Deadline: " + this.getabsoluteDeadline());
		System.out.println("Remaining Time Of Execution: " + this.getremainingTimeOfExecution());
		System.out.println("\n");
	}
}