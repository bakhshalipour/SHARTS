package com.example.classes;

import java.util.Collections;

public class PeriodicTaskSet
{
	private static final int MAX_SIMULATION_TIME = 10000;

	public java.util.ArrayList<PeriodicTask> myTaskSet;
	public java.util.ArrayList<PeriodicTask> sortedMyTaskSetByPeriod;
	public java.util.ArrayList<PeriodicTask> sortedMyTaskSetByRelativeDeadline;
	public int numberOfTasks;
	public int algorithm;
	public String conditionString;
	public boolean isSchedulable;
	public int hyperPeriod;
	public String[] simulationScenario;
	public boolean[] deadlineMisses;
	public boolean[] preemption;
	public int numberOfMisses;
	public float missRate;
	public int numberOfPreemptions;
	public float utilizationFactorOfProcessor;
	public int minorCycle;
	public int majorCycle;
	public int respect;
	public int numberOfTasksInOneTimeLine;
	public String infoString; 
	
	public PeriodicTaskSet(java.util.ArrayList<PeriodicTask> tasks, int numberOfTasks, int algorithm)
	{
		this.myTaskSet = tasks;
		this.numberOfTasks = numberOfTasks;
		this.algorithm = algorithm;

		for (int i = 0; i < myTaskSet.size(); i++)
		{
			this.myTaskSet.get(i).previousPos = i;
		}

		this.conditionString = "";
		this.hyperPeriod = this.GetHyperPeriod();
		this.simulationScenario = new String[MAX_SIMULATION_TIME];
		this.deadlineMisses = new boolean[MAX_SIMULATION_TIME];
		this.preemption = new boolean[MAX_SIMULATION_TIME];
		for (int i = 0; i < MAX_SIMULATION_TIME; i++)
		{
			this.preemption[i] = this.deadlineMisses[i] = false;
			this.simulationScenario[i] = "idle";
		}
		this.numberOfMisses = this.numberOfPreemptions = 0;
		this.missRate = 0;
		this.utilizationFactorOfProcessor = this.GetUtilizationFactorOfProcessor();
		this.majorCycle = this.hyperPeriod;
		this.minorCycle = this.GetMinorCycle();
		this.respect = this.majorCycle / this.minorCycle;

		for (PeriodicTask i : this.myTaskSet)
		{
			i.SetInfoOfTaskInHyperPeriod(this.hyperPeriod);
		}

		this.sortedMyTaskSetByPeriod = this.myTaskSet;
		this.sortedMyTaskSetByRelativeDeadline = this.myTaskSet;
		Collections.sort(this.sortedMyTaskSetByPeriod, PeriodicTask.periodComparator);
		Collections.sort(this.sortedMyTaskSetByRelativeDeadline, PeriodicTask.relativeDeadlineComparator);

		this.UpdateCoeffOfTasksForTL(this.myTaskSet);
		this.UpdateCoeffOfTasksForTL(this.sortedMyTaskSetByPeriod);
		this.UpdateCoeffOfTasksForTL(this.sortedMyTaskSetByRelativeDeadline);

		CheckSchedulability();
		ExecuteSimulation();
		SetExtraInfo();
	}

	public final int GetHyperPeriod()
	{
		int h;
		boolean flag;
		h = Collections.max(this.myTaskSet, PeriodicTask.periodComparator).period;

		while (true)
		{
			flag = true;
			for (PeriodicTask i : this.myTaskSet)
			{
				if (h % i.period != 0)
				{
					flag = false;
				}
			}
			if (flag)
			{
				break;
			}
			else
			{
				h++;
			}
		}

		return h;
	}

	public final float GetUtilizationFactorOfProcessor()
	{
		float u = 0;
		for (PeriodicTask i : this.myTaskSet)
		{
			u += i.utilizationFactor;
		}
		return u;
	}

	public final int GetMinorCycle()
	{
		int g;
		boolean flag;
		g = Collections.min(this.myTaskSet, PeriodicTask.periodComparator).period;

		while (true)
		{
			flag = true;
			for (PeriodicTask i : this.myTaskSet)
			{
				if (i.period % g != 0)
				{
					flag = false;
				}
			}
			if (flag)
			{
				break;
			}
			else
			{
				g--;
			}
		}

		return g;
	}

	public final void CheckSchedulability()
	{
		switch (this.algorithm)
		{
			case 0:
				this.isSchedulable = IsSchedulableByTL();
				break;
			case 1:
				this.isSchedulable = IsSchedulableByRM();
				break;
			case 2:
				this.isSchedulable = IsSchedulableByEDF();
				break;
			case 3:
				this.isSchedulable = IsSchedulableByDM();
				break;
		}
	}

	public final boolean IsSchedulableByTL()
	{
		int maximumNumberOfTasksInOneMinorCycle;
		int temp = 0;
		int respect = this.majorCycle / this.minorCycle;
		int requiredComputationTime = 0;
		boolean isGuaranteed = true;

		for (PeriodicTask i : this.myTaskSet)
		{
			temp += (this.minorCycle * respect) / i.period;
		}

		maximumNumberOfTasksInOneMinorCycle = (int)Math.ceil((double)temp / respect);
		int latchedMaximumNumberOfTasksInOneMinorCycle = maximumNumberOfTasksInOneMinorCycle;
		this.numberOfTasksInOneTimeLine = latchedMaximumNumberOfTasksInOneMinorCycle;

		java.util.ArrayList<PeriodicTask> tempTasks = new java.util.ArrayList<PeriodicTask>(this.myTaskSet);
		Collections.sort(tempTasks, PeriodicTask.computationTimeComparator);

		while (maximumNumberOfTasksInOneMinorCycle != 0)
		{
			requiredComputationTime += tempTasks.get(0).computationTime;
			maximumNumberOfTasksInOneMinorCycle--;
			this.conditionString += "+ " + tempTasks.get(0).computationTime + " ";
			tempTasks.remove(0);
		}

		if (latchedMaximumNumberOfTasksInOneMinorCycle != 1)
		{
			this.conditionString += "= " + requiredComputationTime;
		}
		this.conditionString += " <= " + this.minorCycle;
		if (conditionString.charAt(0) == '+')
		{
			this.conditionString = this.conditionString.substring(2);
		}

		if (requiredComputationTime <= this.minorCycle)
		{
			this.conditionString += "\tTrue";
			this.conditionString += "\n" + "TaskSet is schedulable by TimeLine algorithm.";
		}
		else
		{
			this.conditionString += "\tFalse";
			isGuaranteed = false;
			this.conditionString += "\n" + "TaskSet isn't schedulable by TimeLine algorithm.";
		}

		return isGuaranteed;

	}

	public final boolean IsSchedulableByRM()
	{
		boolean flag = true;
		float uLUB = (float)(this.numberOfTasks * (Math.pow(2, (float)1 / this.numberOfTasks) - 1));
		this.conditionString += "Checking upper-bound limit: " + "\n";
		this.conditionString += "U_LUB = n * (2 ^ (1/n) - 1) -> U_LUB = " + uLUB + "\n";
		for (int i = 0; i < this.myTaskSet.size(); i++)
		{
			if (i == 0)
			{
				this.conditionString += this.myTaskSet.get(i).utilizationFactor;
			}
			else
			{
				this.conditionString += " + " + this.myTaskSet.get(i).utilizationFactor;
			}
		}
		if (this.numberOfTasks != 1)
		{
			this.conditionString += " = " + this.utilizationFactorOfProcessor;
		}
		this.conditionString += " <= " + uLUB + "\t";
		if (this.utilizationFactorOfProcessor <= uLUB)
		{
			this.conditionString += "True";
		}
		else
		{
			this.conditionString += "False";
			flag = false;
		}

		if (flag)
		{
			this.conditionString += "\n" + "TaskSet is schedulable by RM.";
			return true;
		}
		else
		{
			this.conditionString += "\n" + "This condition doesn't match. Checking Hyperbolic condition: " + "\n";
		}

		flag = true;
		float uHyperbolic = 1;

		for (int i = 0; i < this.myTaskSet.size(); i++)
		{
			if (i == 0)
			{
				this.conditionString += "(1 + " + this.myTaskSet.get(i).utilizationFactor + ")";
			}
			else
			{
				this.conditionString += " * (1 + " + this.myTaskSet.get(i).utilizationFactor + ")";
			}
			uHyperbolic *= 1 + this.myTaskSet.get(i).utilizationFactor;
		}
		if (this.numberOfTasks != 1)
		{
			this.conditionString += " = " + uHyperbolic;
		}
		this.conditionString += " <= 2";
		if (uHyperbolic <= 2)
		{
			this.conditionString += "\tTrue" + "\n";
		}
		else
		{
			this.conditionString += "\tFalse" + "\n";
			flag = false;
		}
		if (flag)
		{
			this.conditionString += "TaskSet is schedulable by RM." + "\n";
			return true;
		}
		else
		{
			this.conditionString += "We can not guarantee schedulability by RM." + "\n";
		}

		return false;
	}


	public final boolean IsSchedulableByEDF()
	{
		for (int i = 0; i < this.myTaskSet.size(); i++)
		{
			if (i == 0)
			{
				this.conditionString += this.myTaskSet.get(i).utilizationFactor;
			}
			else
			{
				this.conditionString += " + " + this.myTaskSet.get(i).utilizationFactor;
			}
		}

		if (this.numberOfTasks != 1)
		{
			this.conditionString += " = " + this.utilizationFactorOfProcessor;
		}
		this.conditionString += " <= 1";
		if (this.utilizationFactorOfProcessor <= 1)
		{
			this.conditionString += "\tTrue" + "\n" + "TaskSet is schedulable by EDF.";
		}
		else
		{
			this.conditionString += "\tFalse" + "\n" + "TaskSet isn't schedulable by EDF.";
		}

		return (this.utilizationFactorOfProcessor <= 1);
	}

	public final boolean IsSchedulableByDM()
	{
		float uDM = 0;
		for (int i = 0; i < this.myTaskSet.size(); i++)
		{
			if (i == 0)
			{
				this.conditionString += this.myTaskSet.get(i).utilizationFactorDeadlineMonotonic;
			}
			else
			{
				this.conditionString += " + " + this.myTaskSet.get(i).utilizationFactorDeadlineMonotonic;
			}
			uDM += this.myTaskSet.get(i).utilizationFactorDeadlineMonotonic;
		}

		float uLUBDM = (float)(this.numberOfTasks * (Math.pow(2, (float)1 / this.numberOfTasks) - 1));

		if (this.numberOfTasks != 1)
		{
			this.conditionString += " = " + uDM;
		}
		this.conditionString += " <= " + uLUBDM;

		if (uDM <= uLUBDM)
		{
			this.conditionString += "\tTrue" + "\n" + "TaskSet is schedulable by Deadline Monotonic";
		}
		else
		{
			this.conditionString += "\tFalse" + "\n" + "We can not guarantee scheduling under Deadline Monotonic";
		}

		return (uDM <= uLUBDM);
	}

	public final void ExecuteSimulation()
	{
		switch (this.algorithm)
		{
			case 0:
				ExecuteSimulationByTLAlgorithm();
				break;
			case 1:
				ExecuteSimulationByRMAlgorithm();
				break;
			case 2:
				ExecuteSimulationByEDFAlgorithm();
				break;
			case 3:
				ExecuteSimulationByDMAlgorithm();
				break;
		}
	}

	public final void ExecuteSimulationByTLAlgorithm()
	{
		java.util.ArrayList<PeriodicTask> copyOfMyTasks = new java.util.ArrayList<PeriodicTask>();
		copyOfMyTasks = this.myTaskSet;
		Collections.sort(copyOfMyTasks, PeriodicTask.coeffOfMinorCycleComparator);
		int copyOfTasksInOneTimeLine = this.numberOfTasksInOneTimeLine;
		int index = 0;

		for (int t = 0; t < this.majorCycle; t++)
		{

			for (PeriodicTask i : copyOfMyTasks)
			{
				i.UpdateRemainingTimeOfExecution(t);
			}


			if (t % this.minorCycle == 0)
			{
				copyOfTasksInOneTimeLine = this.numberOfTasksInOneTimeLine;
				if (copyOfMyTasks.get(index).HasNeedToExecute() && t != 0 && !this.simulationScenario[t - 1].equals("idle"))
				{
					this.deadlineMisses[t] = true;
				}
			}

			if (copyOfTasksInOneTimeLine == 0)
			{
				continue;
			}

			index = 0;
			while (index < this.numberOfTasks && !copyOfMyTasks.get(index).HasNeedToExecute())
			{
				index++;
			}
			if (index == this.numberOfTasks)
			{
				continue;
			}

			copyOfMyTasks.get(index).ExecuteOneCycle();

			if (!copyOfMyTasks.get(index).HasNeedToExecute())
			{
				copyOfMyTasks.get(index).SetFinishingTime(t + 1);
				copyOfMyTasks.get(index).UpdateJobShouldBeDone();
				copyOfTasksInOneTimeLine--;
			}

			this.simulationScenario[t] = copyOfMyTasks.get(index).name;

		}
	}

	public final void ExecuteSimulationByRMAlgorithm()
	{
		int index;
		boolean flag = false;
		for (int t = 0; t < this.hyperPeriod; t++)
		{
			for (PeriodicTask i : this.sortedMyTaskSetByPeriod)
			{
				if (i.MissedDeadline(t))
				{
					this.deadlineMisses[t] = true;
				}
			}

			for (PeriodicTask i : this.sortedMyTaskSetByPeriod)
			{
				i.UpdateRemainingTimeOfExecution(t);
			}

			index = 0;
			while (index < this.numberOfTasks && !this.sortedMyTaskSetByPeriod.get(index).HasNeedToExecute())
			{
				index++;
			}

			if (index == this.numberOfTasks)
			{
				continue;
			}

			this.sortedMyTaskSetByPeriod.get(index).ExecuteOneCycle();
			this.simulationScenario[t] = this.sortedMyTaskSetByPeriod.get(index).name;

			if (t != 0 && !flag && !this.simulationScenario[t].equals(this.simulationScenario[t - 1]) && !this.simulationScenario[t - 1].equals("idle"))
			{
				preemption[t] = true;
			}

			flag = false;
			if (!this.sortedMyTaskSetByPeriod.get(index).HasNeedToExecute())
			{
				flag = true;
				this.sortedMyTaskSetByPeriod.get(index).SetFinishingTime(t + 1);
				this.sortedMyTaskSetByPeriod.get(index).UpdateJobShouldBeDone();
			}

		}
	}

	public final void ExecuteSimulationByEDFAlgorithm()
	{
		int index = 0;
		boolean flag = false;

		for (int t = 0; t < this.hyperPeriod; t++)
		{
			for (PeriodicTask i : this.myTaskSet)
			{
				if (i.MissedDeadline(t))
				{
					this.deadlineMisses[t] = true;
				}
			}

			for (PeriodicTask i : this.myTaskSet)
			{
				i.UpdateTimeToDeadline(t);
				i.UpdateRemainingTimeOfExecution(t);
			}

			Collections.sort(this.myTaskSet, PeriodicTask.reverseTimeToDeadLineComparator);
			index = 0;
			while (index < this.numberOfTasks && !this.myTaskSet.get(index).HasNeedToExecute())
			{
				index++;
			}
			if (index == this.numberOfTasks)
			{
				continue;
			}

			this.myTaskSet.get(index).ExecuteOneCycle();
			this.simulationScenario[t] = this.myTaskSet.get(index).name;

			if (t != 0 && !flag && !this.simulationScenario[t].equals(this.simulationScenario[t - 1]) && !this.simulationScenario[t - 1].equals("idle"))
			{
				preemption[t] = true;
			}

			flag = false;
			if (!this.myTaskSet.get(index).HasNeedToExecute())
			{
				flag = true;
				this.myTaskSet.get(index).SetFinishingTime(t + 1);
				this.myTaskSet.get(index).UpdateJobShouldBeDone();
			}

		}
	}

	public final void ExecuteSimulationByDMAlgorithm()
	{
		int index;
		boolean flag = false;
		for (int t = 0; t < this.hyperPeriod; t++)
		{
			for (PeriodicTask i : this.sortedMyTaskSetByRelativeDeadline)
			{
				if (i.MissedDeadline(t))
				{
					this.deadlineMisses[t] = true;
				}
			}

			for (PeriodicTask i : this.sortedMyTaskSetByRelativeDeadline)
			{
				i.UpdateRemainingTimeOfExecution(t);
			}

			index = 0;
			while (index < this.numberOfTasks && !this.sortedMyTaskSetByRelativeDeadline.get(index).HasNeedToExecute())
			{
				index++;
			}

			if (index == this.numberOfTasks)
			{
				continue;
			}

			this.sortedMyTaskSetByRelativeDeadline.get(index).ExecuteOneCycle();
			this.simulationScenario[t] = this.sortedMyTaskSetByRelativeDeadline.get(index).name;

			if (t != 0 && !flag && !this.simulationScenario[t].equals(this.simulationScenario[t - 1]) && !this.simulationScenario[t - 1].equals("idle"))
			{
				preemption[t] = true;
			}

			flag = false;
			if (!this.sortedMyTaskSetByRelativeDeadline.get(index).HasNeedToExecute())
			{
				flag = true;
				this.sortedMyTaskSetByRelativeDeadline.get(index).SetFinishingTime(t + 1);
				this.sortedMyTaskSetByRelativeDeadline.get(index).UpdateJobShouldBeDone();
			}

		}
	}

	public final void UpdateCoeffOfTasksForTL(java.util.ArrayList<PeriodicTask> L)
	{
		for (PeriodicTask i : L)
		{
			i.coeffOfMinorCycle = i.period / this.minorCycle;
		}
	}

	public final void SetExtraInfo()
	{
		for (boolean i : this.deadlineMisses)
		{
			if (i)
			{
				this.numberOfMisses++;
			}
		}

		for (boolean i : this.preemption)
		{
			if (i)
			{
				this.numberOfPreemptions++;
			}
		}

		this.missRate = (float)this.numberOfMisses / this.numberOfTasks;
		
        this.infoString = "";
        this.infoString += "Number Of Misses = " + this.numberOfMisses + "\n";
        this.infoString += "Miss Rate = " + this.missRate + "\n";
        this.infoString += "Number Of Preemption = " + this.numberOfPreemptions;
	}

	public final void PrintTaskSetInfo()
	{
		for (int i = 0; i < this.hyperPeriod; i++)
		{
			System.out.println(i + "\t" + this.simulationScenario[i] + "\t" + this.deadlineMisses[i] + "\t" + this.preemption[i]);
		}
		System.out.println("MissCounter = " + this.numberOfMisses);
		System.out.println("PreemptionCounter = " + this.numberOfPreemptions);
		System.out.println("MissRate = " + this.missRate);

	}

}