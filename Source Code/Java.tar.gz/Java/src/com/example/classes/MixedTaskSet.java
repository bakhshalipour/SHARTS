package com.example.classes;

import java.util.Collections;

public class MixedTaskSet
{
	private static final int MAX_SIMULATION_TIME = 10000;

	public PeriodicTaskSet myPeriodicTaskSet;
	public java.util.ArrayList<AperiodicTask> myAperiodicTasks;
	public String[] simulationScenario;
	public int simulationTime;
	public String conditionString;
	public int hyperPeriod;
	public boolean[] deadlineMisses;
	public boolean[] preemption;
	public int numberOfMisses;
	public float missRate;
	public int numberOfPreemptions;
	public float utilizationFactorOfProcessor;
	public String infoString;


	public MixedTaskSet(java.util.ArrayList<PeriodicTask> periodicTasks, java.util.ArrayList<AperiodicTask> aperiodicTasks, int algorithm)
	{
		this.simulationScenario = new String[MAX_SIMULATION_TIME];
		this.deadlineMisses = new boolean[MAX_SIMULATION_TIME];
		this.preemption = new boolean[MAX_SIMULATION_TIME];
		myPeriodicTaskSet = new PeriodicTaskSet(periodicTasks, periodicTasks.size(), algorithm);
		this.myAperiodicTasks = aperiodicTasks;
		//this.myAperiodicTasks = this.myAperiodicTasks.OrderBy(o -> o.releaseTime).ToList();
		Collections.sort(this.myAperiodicTasks, AperiodicTask.releaseTimeComparator);
		this.simulationTime = 2 * myPeriodicTaskSet.hyperPeriod;
		SetSomeExtraInfoAboutPeriodics();
		ExecuteSimulationForPeriodics();
		ExecuteSimulationForAperiodics();
		ComputeUtilizationFactorOfAllTasks();
		
		this.infoString = this.myPeriodicTaskSet.infoString; 
	}

	public final void SetSomeExtraInfoAboutPeriodics()
	{
		this.conditionString = this.myPeriodicTaskSet.conditionString;
		this.hyperPeriod = this.myPeriodicTaskSet.hyperPeriod;
		this.deadlineMisses = this.myPeriodicTaskSet.deadlineMisses;
		this.preemption = this.myPeriodicTaskSet.preemption;
		this.numberOfMisses = this.myPeriodicTaskSet.numberOfMisses;
		this.missRate = this.myPeriodicTaskSet.missRate;
		this.numberOfPreemptions = this.myPeriodicTaskSet.numberOfPreemptions;
	}

	public final void ComputeUtilizationFactorOfAllTasks()
	{
		int u = 0;

		for (int i = 0; i < this.simulationTime; i++)
		{
			if (!this.simulationScenario[i].equals("idle"))
			{
				u++;
			}
		}

		this.utilizationFactorOfProcessor = (float)u / this.simulationTime;
	}

	public final void ExecuteSimulationForPeriodics()
	{
		for (int i = 0; i < this.simulationTime; i++)
		{
			this.simulationScenario[i] = this.myPeriodicTaskSet.simulationScenario[i % this.hyperPeriod];
		}
	}

	public final void ExecuteSimulationForAperiodics()
	{
		int index = 0;
		int numberOfAperiodicRequests = this.myAperiodicTasks.size();

		for (int t = 0; t < this.simulationTime; t++)
		{
			if (this.simulationScenario[t].equals("idle"))
			{
				index = 0;
				while (index < numberOfAperiodicRequests && !this.myAperiodicTasks.get(index).HasNeedToExecute())
				{
					index++;
				}
				if (index == numberOfAperiodicRequests)
				{
					continue;
				}

				if (this.myAperiodicTasks.get(index).IsReleased(t))
				{
					this.myAperiodicTasks.get(index).ExecuteOneCycle();
					this.simulationScenario[t] = this.myAperiodicTasks.get(index).getname();
				}

			}
		}
	}

	public final void PrintTaskSetInfo()
	{
		for (int i = 0; i < this.simulationTime; i++)
		{
			System.out.println(i + "\t" + this.simulationScenario[i] + "\t" + this.deadlineMisses[i] + "\t" + this.preemption[i]);
		}

		System.out.println("MissCounter = " + this.numberOfMisses);
		System.out.println("MissRate = " + this.missRate);
		System.out.println("Preemption = " + this.numberOfPreemptions);
		System.out.println("Utilization Factor of All = " + this.utilizationFactorOfProcessor);
	}
}