package com.example.classes;

import java.util.ArrayList;
import java.util.List;

public class Algorithm {
	public TaskSet taskSet;
	public List<Task> result = new ArrayList<Task>();
	public Algorithm(TaskSet taskSet){
		this.taskSet=taskSet;
	}
	public boolean isValid(){
		return true;
	}
	public void Perform(){
	}
	public List<Task> GetResult(){
		return result;
	}
}
