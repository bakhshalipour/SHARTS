package com.example.classes;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import android.graphics.Color;

public class Task {
	public int color	;
	public String name				= "";
	public int computationTime		= 0;
	public int deadLine				= 0;
	public int period				= 0;
	public int releaseTime			= 0;
	
	public int remainCTime			= 0;
	public Task(){
		color = Color.rgb(new Random().nextInt(256), new Random().nextInt(256), new Random().nextInt(256));
	}
	public void Prepare(int t){
		if(t % period == 0)
			remainCTime = computationTime;
	}
	public boolean isRunning(int t){
		return (t>=releaseTime && remainCTime >0);
	}
	public float GetU(){
		return (float)computationTime/period;
	}
	public int GetDeadLine(int t){
		int i = 0;
		while(releaseTime+period*i+deadLine < t){
			i++;
		}
		return releaseTime+period*i+deadLine;
	}
}
