package com.example.classes;

import java.util.Comparator;
import java.util.Random;

import android.graphics.Color;

public class PeriodicTask implements Cloneable
{
	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	private static final int MAX_RELEASES = 10000;
	public int color;
	public String name;
	public int computationTime;
	public int period;
	public int relativeDeadline;
	public float utilizationFactor;
	public float utilizationFactorDeadlineMonotonic;
	public int remainingTimeOfExecution;
	public int[] finishingTime;
	public int previousPos;
	public int coeffOfMinorCycle;
	public int timeToDeadline;

	public int numberOfReleasesInHyperPeriod;
	public int indexOfJobShouldBeDone;
	public int[] taskReleasesInHyperPeriod;
	public int[] taskDeadlinesInHyperPeriod;
	
	public static Comparator<PeriodicTask> periodComparator = new Comparator<PeriodicTask>()
	{
		public int compare (PeriodicTask t1, PeriodicTask t2)
		{
			int period1 = t1.period;
			int period2 = t2.period;
			return period1 - period2;
		}
	};
	
	public static Comparator<PeriodicTask> relativeDeadlineComparator = new Comparator<PeriodicTask>()
	{
		public int compare (PeriodicTask t1, PeriodicTask t2)
		{
			int relativeDeadline1 = t1.relativeDeadline;
			int relativeDeadline2 = t2.relativeDeadline;
			return relativeDeadline1 - relativeDeadline2;
		}
	};
	
	public static Comparator<PeriodicTask> computationTimeComparator = new Comparator<PeriodicTask>()
	{
		public int compare (PeriodicTask t1, PeriodicTask t2)
		{
			int computationTime1 = t1.computationTime;
			int computationTime2 = t2.computationTime;
			return computationTime1 - computationTime2;
		}
	};
	
	public static Comparator<PeriodicTask> coeffOfMinorCycleComparator = new Comparator<PeriodicTask>()
	{
		public int compare (PeriodicTask t1, PeriodicTask t2)
		{
			int coeffOfMinorCycle1 = t1.coeffOfMinorCycle;
			int coeffOfMinorCycle2 = t2.coeffOfMinorCycle;
			return coeffOfMinorCycle1 - coeffOfMinorCycle2;
		}
	};
	
	public static Comparator<PeriodicTask> timeToDeadLineComparator = new Comparator<PeriodicTask>()
	{
		public int compare (PeriodicTask t1, PeriodicTask t2)
		{
			int timeToDeadLine1 = t1.timeToDeadline;
			int timeToDeadLine2 = t2.timeToDeadline;
			return timeToDeadLine1 - timeToDeadLine2;
		}
	};
	
	public static Comparator<PeriodicTask> reverseTimeToDeadLineComparator = new Comparator<PeriodicTask>()
	{
		public int compare (PeriodicTask t1, PeriodicTask t2)
		{
			int timeToDeadLine1 = t1.timeToDeadline;
			int timeToDeadLine2 = t2.timeToDeadline;
			return timeToDeadLine2 - timeToDeadLine1;
		}
	};

	public PeriodicTask(String name, int computationTime, int period, int relativeDeadline)
	{
		color = Color.rgb(new Random().nextInt(150)+106, new Random().nextInt(150)+106, new Random().nextInt(150)+106);
		this.name = name;
		this.computationTime = computationTime;
		this.period = period;
		this.relativeDeadline = relativeDeadline;
		this.utilizationFactor = (float) this.computationTime / this.period;
		this.utilizationFactorDeadlineMonotonic = (float)this.computationTime / this.relativeDeadline;
		this.taskReleasesInHyperPeriod = new int[MAX_RELEASES];
		this.taskDeadlinesInHyperPeriod = new int[MAX_RELEASES];
		this.finishingTime = new int[MAX_RELEASES];
		this.indexOfJobShouldBeDone = 0;
		this.remainingTimeOfExecution = this.computationTime;
		this.UpdateTimeToDeadline(0);
	}

	public final void SetInfoOfTaskInHyperPeriod(int h)
	{
		this.numberOfReleasesInHyperPeriod = h / this.period;

		int index = 0;
		for (int t = 0; t < h; t++)
		{
			if (t % this.period == 0)
			{
				this.taskReleasesInHyperPeriod[index++] = t;
			}
		}

		for (int i = 0; i < index; i++)
		{
			this.taskDeadlinesInHyperPeriod[i] = this.taskReleasesInHyperPeriod[i] + this.relativeDeadline;
		}
	}

	public final void UpdateRemainingTimeOfExecution(int t)
	{
		if (t % this.period == 0 && t != 0)
		{
			this.remainingTimeOfExecution += this.computationTime;
		}
	}

	public final void ExecuteOneCycle()
	{
		this.remainingTimeOfExecution--;
	}

	public final boolean HasNeedToExecute()
	{
		return (this.remainingTimeOfExecution > 0);
	}

	public final int GetThisJobDeadline()
	{
		return this.taskDeadlinesInHyperPeriod[this.indexOfJobShouldBeDone];
	}

	public final void UpdateJobShouldBeDone()
	{
		if (this.indexOfJobShouldBeDone < this.numberOfReleasesInHyperPeriod - 1)
		{
			this.indexOfJobShouldBeDone++;
		}
	}

	public final boolean MissedDeadline(int t)
	{
		if (this.HasNeedToExecute() && t == this.GetThisJobDeadline())
		{
			return true;
		}
		return false;
	}

	public final void SetFinishingTime(int t)
	{
		this.finishingTime[this.indexOfJobShouldBeDone] = t;
	}

	public final void UpdateTimeToDeadline(int t)
	{
		this.timeToDeadline = t - this.GetThisJobDeadline();
	}

	public final void PrintTaskInfo()
	{
		System.out.println("Task Name: " + this.name);
		System.out.println("Computation Time: " + this.computationTime);
		System.out.println("Period: " + this.period);
		System.out.println("Relative Deadline: " + this.relativeDeadline);
		System.out.println("Utilization Factor: " + this.utilizationFactor);
		System.out.println("Number Of Releases In One HyperPeriod: " + this.numberOfReleasesInHyperPeriod);
		System.out.println("Remaining Time Of Execution: " + this.remainingTimeOfExecution);
		System.out.println("Index Of Job Should Be Done: " + this.indexOfJobShouldBeDone);
		System.out.println("This Job Deadline is: " + this.GetThisJobDeadline());
		System.out.println("Task Releases In One HyperPeriod: ");
		for (int i = 0; i < this.numberOfReleasesInHyperPeriod; i++)
		{
			System.out.println(this.taskReleasesInHyperPeriod[i]);
		}
		System.out.println("Task Deadlines In One HyperPeriod: ");
		for (int i = 0; i < this.numberOfReleasesInHyperPeriod; i++)
		{
			System.out.println(this.taskDeadlinesInHyperPeriod[i]);
		}
	}
}