package com.example.chartproject;

import java.util.ArrayList;









import java.util.List;

import com.example.classes.AperiodicTask;
import com.example.classes.AperiodicTaskSet;
import com.example.classes.HorizontalListView;
import com.example.classes.MixedTaskSet;
import com.example.classes.PeriodicTask;
import com.example.classes.PeriodicTaskSet;
import com.example.classes.Task;
import com.example.classes.TaskSet;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.View.OnFocusChangeListener;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.widget.AdapterView.OnItemClickListener;

public class MainActivityBoth extends Activity {
	public  java.util.ArrayList<PeriodicTask> PeriodicTaskSet = new ArrayList<PeriodicTask>();
	public  java.util.ArrayList<AperiodicTask> AperiodicTaskSet = new ArrayList<AperiodicTask>();
	Context mContext;

	MyAdapterPeriodic adapterPeriodic;
	MyAdapterAperiodic adapterAperiodic;
	ListView lv_p,lv_ap;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main_both);
		mContext = this;

		lv_p = (ListView)findViewById(R.id.listView1);
		lv_ap = (ListView)findViewById(R.id.listView2);
		adapterPeriodic = new MyAdapterPeriodic(mContext, 0, 0, PeriodicTaskSet);
		adapterAperiodic = new MyAdapterAperiodic(mContext, 0, 0, AperiodicTaskSet);
		lv_p.setAdapter(adapterPeriodic);
		lv_ap.setAdapter(adapterAperiodic);
		
		lv_p.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, final int arg2,
					long arg3) {
				final AlertDialog.Builder alerBuilder = new AlertDialog.Builder(mContext);
				alerBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						PeriodicTaskSet.remove(arg2);
						adapterPeriodic.notifyDataSetChanged();
					}
				})
				.setNegativeButton("No", null)
				.setMessage("Are you sure ?")
				.setTitle("Delete task")
				.setCancelable(true)
				.show();
			}
		});
		
		lv_ap.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, final int arg2,
					long arg3) {
				final AlertDialog.Builder alerBuilder = new AlertDialog.Builder(mContext);
				alerBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						AperiodicTaskSet.remove(arg2);
						adapterAperiodic.notifyDataSetChanged();
					}
				})
				.setNegativeButton("No", null)
				.setMessage("Are you sure ?")
				.setTitle("Delete task")
				.setCancelable(true)
				.show();
			}
		});
	}

	public void NewTask(View v){
		String items[] = {"Add a periodic task","Add a aperiodic task"};
		final AlertDialog.Builder alerBuilder = new AlertDialog.Builder(mContext);
		alerBuilder.setItems(items, new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				if(which == 0)
					NewTaskPeriodic();
				
				if(which == 1)
					NewTaskAperiodic();
			}
		})
		.setCancelable(true).show();
	}
	public void NewTaskPeriodic(){
		LayoutInflater layoutInflater = LayoutInflater.from(mContext);
		View promptView			= layoutInflater.inflate(R.layout.viewer_new_task_dialoq, null);

		final EditText et_name		= (EditText)promptView.findViewById(R.id.et_name);
		final EditText et_time		= (EditText)promptView.findViewById(R.id.editText1);
		final EditText et_deadLine	= (EditText)promptView.findViewById(R.id.editText2);
		final EditText et_relaseTime= (EditText)promptView.findViewById(R.id.editText3);
		final EditText et_period	= (EditText)promptView.findViewById(R.id.editText4);
		final AlertDialog.Builder alerBuilder = new AlertDialog.Builder(mContext);
		alerBuilder.setView(promptView);

		TextView t_relaseTime		= (TextView)promptView.findViewById(R.id.textView3);
		et_relaseTime.setVisibility(View.GONE);
		t_relaseTime.setVisibility(View.GONE);
		
		et_period.setOnFocusChangeListener(new OnFocusChangeListener() {
			
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				if((et_deadLine.getText().toString()+"").equals("0") ||  (et_deadLine.getText().toString()+"").equals("")){
					if(!(et_period.getText().toString()+"").equals("")){
						et_deadLine.setText(et_period.getText().toString()+"");
					}
				}
			}
		});
		
		alerBuilder.setPositiveButton("Add", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				String name 	= et_name.getText().toString()+"";
				String time		= et_time.getText().toString()+"";
				String dead		= et_deadLine.getText().toString()+"";
				String rel		= et_relaseTime.getText().toString()+"";
				String period	= et_period.getText().toString()+"";
				
				if(name.equals("") ){
					Toast.makeText(mContext, "name can not be empty", Toast.LENGTH_LONG).show();
					alerBuilder.show();
					return;
				}

				if(period.equals("") || period.equals("0")){
					Toast.makeText(mContext, "Period must be > 0", Toast.LENGTH_LONG).show();
					return;
				}
				
				if(dead.equals("") || dead.equals("0")){
					Toast.makeText(mContext, "Deadline must be > 0", Toast.LENGTH_LONG).show();
					return;
				}
				
				if(time.equals("")|| time.equals("0") ){
					Toast.makeText(mContext, "Computation time must be > 0" , Toast.LENGTH_LONG).show();
					return;
				}

				for(AperiodicTask pt: AperiodicTaskSet){
					if(pt.getname().equals(name)){
						Toast.makeText(mContext, "Duplicate task name" , Toast.LENGTH_LONG).show();
						return;
					}
				}	
				
				for(PeriodicTask pt: PeriodicTaskSet){
					if(pt.name.equals(name)){
						Toast.makeText(mContext, "Duplicate task name" , Toast.LENGTH_LONG).show();
						return;
					}
				}	
				
				PeriodicTask t = new PeriodicTask(name,Integer.parseInt(time),Integer.parseInt(period),Integer.parseInt(dead));
				PeriodicTaskSet.add(t);
				adapterPeriodic.notifyDataSetChanged();
			}
		}).setCancelable(true).create().show();
	}
	public void NewTaskAperiodic(){
		LayoutInflater layoutInflater = LayoutInflater.from(mContext);
		View promptView			= layoutInflater.inflate(R.layout.viewer_new_task_dialoq, null);

		final EditText et_name		= (EditText)promptView.findViewById(R.id.et_name);
		final EditText et_time		= (EditText)promptView.findViewById(R.id.editText1);
		final EditText et_deadLine	= (EditText)promptView.findViewById(R.id.editText2);
		final EditText et_relaseTime= (EditText)promptView.findViewById(R.id.editText3);
		final EditText et_period	= (EditText)promptView.findViewById(R.id.editText4);
		final AlertDialog.Builder alerBuilder = new AlertDialog.Builder(mContext);
		alerBuilder.setView(promptView);

		TextView t_period 			= (TextView)promptView.findViewById(R.id.textView4);
		et_period.setVisibility(View.GONE);
		t_period.setVisibility(View.GONE);
		
		TextView t_dead 			= (TextView)promptView.findViewById(R.id.textView2);
		et_deadLine.setVisibility(View.GONE);
		t_dead.setVisibility(View.GONE);
		
		alerBuilder.setPositiveButton("Add", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				String name 	= et_name.getText().toString()+"";
				String time		= et_time.getText().toString()+"";
				String dead		= et_deadLine.getText().toString()+"";
				String rel		= et_relaseTime.getText().toString()+"";
				String period	= et_period.getText().toString()+"";
				if(name.equals("") ){
					Toast.makeText(mContext, "name can not be empty", Toast.LENGTH_LONG).show();
					return;
				}

				
				if(time.equals("")|| time.equals("0") ){
					Toast.makeText(mContext, "Computation time must be > 0" , Toast.LENGTH_LONG).show();
					return;
				}

				for(AperiodicTask pt: AperiodicTaskSet){
					if(pt.getname().equals(name)){
						Toast.makeText(mContext, "Duplicate task name" , Toast.LENGTH_LONG).show();
						return;
					}
				}	
				
				for(PeriodicTask ppt: PeriodicTaskSet){
					if(ppt.name.equals(name)){
						Toast.makeText(mContext, "Duplicate task name" , Toast.LENGTH_LONG).show();
						return;
					}
				}	
				
				AperiodicTask t = new AperiodicTask(name,Integer.parseInt(rel),Integer.parseInt(time),0);
				AperiodicTaskSet.add(t);
				adapterAperiodic.notifyDataSetChanged();
			}
		}).setCancelable(true).create().show();
	}
	public void Analysis(View v){

		final String items[] = {"TimeLine","Rate Monotonic","EDF","Deadline Monotonic"};
		final AlertDialog.Builder alerBuilder = new AlertDialog.Builder(mContext);
		alerBuilder.setItems(items, new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				Toast.makeText(mContext, items[which], Toast.LENGTH_LONG).show();
				try {
					ShowAnalysis (items[which]);
				} catch (CloneNotSupportedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		alerBuilder.setTitle("Choose scheduling algorithm for Periodic tasks");
		alerBuilder.setCancelable(true).show();

	}
	public void ShowAnalysis(final String  Algorthm) throws CloneNotSupportedException{
		
		ChartActivity.PeriodicTaskSet  = PeriodicTaskSet;
		ChartActivity.AperiodicTaskSet  = AperiodicTaskSet;
		final Intent i = new Intent (mContext,ChartActivity.class);
		i.putExtra("Method", "Mixed");
		
		int Alg = 0;
		if(Algorthm.equals("TimeLine"))
			Alg = 0;
		
		if(Algorthm.equals("Rate Monotonic"))
			Alg = 1;
		
		if(Algorthm.equals("EDF"))
			Alg = 2;
		
		if(Algorthm.equals("Deadline Monotonic"))
			Alg = 3;
		
		ArrayList<PeriodicTask> pts = new ArrayList<PeriodicTask>();
		for(PeriodicTask t : PeriodicTaskSet){
			pts.add((PeriodicTask) t.clone());
		}
		
		ArrayList<AperiodicTask> ats = new ArrayList<AperiodicTask>();
		for(AperiodicTask t : AperiodicTaskSet){
			ats.add((AperiodicTask) t.clone());
		}
		
		MixedTaskSet apts = new MixedTaskSet(pts, ats, Alg);
		final AlertDialog.Builder alerBuilder = new AlertDialog.Builder(mContext);
		alerBuilder.setTitle("Analysis :")
		.setMessage(apts.conditionString)
		.setPositiveButton("Run", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				i.putExtra("Algorithm",Algorthm);
				startActivity(i);
			}
		}).setCancelable(true).show();
	}
	public class MyAdapterPeriodic extends ArrayAdapter<PeriodicTask>{
		LayoutInflater inflater ;
		public MyAdapterPeriodic(Context context, int resource, int textViewResourceId,List<PeriodicTask> posts) {
			super(context, resource, textViewResourceId, posts);
			inflater = (LayoutInflater)mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		}

		public View getView(final int position,View row,ViewGroup parent){
			row = inflater.inflate(R.layout.viewer_task, parent, false);
			View 	color	 = (View)row.findViewById(R.id.color);
			TextView tv_name = (TextView)row.findViewById(R.id.name);
			TextView tv_time = (TextView)row.findViewById(R.id.time);
			TextView tv_dead = (TextView)row.findViewById(R.id.dead);

			color.setBackgroundColor( PeriodicTaskSet.get(position).color);
			tv_name.setText( PeriodicTaskSet.get(position).name);
			tv_time.setText("c: "+ PeriodicTaskSet.get(position).computationTime + " s");
			tv_dead.setText("d: "+ PeriodicTaskSet.get(position).relativeDeadline + " s");
			return row;
		}
	}
	public class MyAdapterAperiodic extends ArrayAdapter<AperiodicTask>{
		LayoutInflater inflater ;
		public MyAdapterAperiodic(Context context, int resource, int textViewResourceId,List<AperiodicTask> posts) {
			super(context, resource, textViewResourceId, posts);
			inflater = (LayoutInflater)mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		}

		public View getView(final int position,View row,ViewGroup parent){
			row = inflater.inflate(R.layout.viewer_task, parent, false);
			View 	color	 = (View)row.findViewById(R.id.color);
			TextView tv_name = (TextView)row.findViewById(R.id.name);
			TextView tv_time = (TextView)row.findViewById(R.id.time);
			TextView tv_dead = (TextView)row.findViewById(R.id.dead);

			color.setBackgroundColor( AperiodicTaskSet.get(position).color);
			tv_name.setText( AperiodicTaskSet.get(position).getname());
			tv_time.setText("c: "+ AperiodicTaskSet.get(position).getcomputationTime() + " s");
			tv_dead.setText("r: "+ AperiodicTaskSet.get(position).getreleaseTime() + " s");
			return row;
		}
	}

}
