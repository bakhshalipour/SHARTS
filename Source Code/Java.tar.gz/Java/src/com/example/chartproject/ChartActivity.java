package com.example.chartproject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.example.algorithms.edf;
import com.example.classes.AperiodicTask;
import com.example.classes.AperiodicTaskSet;
import com.example.classes.HorizontalListView;
import com.example.classes.MixedTaskSet;
import com.example.classes.PeriodicTask;
import com.example.classes.PeriodicTaskSet;
import com.example.classes.Task;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ChartActivity extends Activity {
	public String[] tasks;
	public boolean[] misses;
	public boolean[] pris;
	public int scale	= 100;
	
	public static ArrayList<AperiodicTask> AperiodicTaskSet = new ArrayList<AperiodicTask>();
	public static ArrayList<PeriodicTask> PeriodicTaskSet = new ArrayList<PeriodicTask>();
	
	TextView tv_info;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.activity_chart);
		super.onCreate(savedInstanceState);

		tv_info		= (TextView)findViewById(R.id.info);
		
		HorizontalListView listview = (HorizontalListView) findViewById(R.id.lv);
		listview.setAdapter(mAdapter);

		String method	= getIntent().getExtras().getString("Method");
		String algorithm= getIntent().getExtras().getString("Algorithm");
		
		if(method.equals("Aperiodic")){
			try {
				Aperiodic(algorithm);
			} catch (CloneNotSupportedException e) {
			}
		
		}
		if(method.equals("Periodic")){
			try {
				Periodic(algorithm);
			} catch (CloneNotSupportedException e) {
				e.printStackTrace();
			}
		}
		if(method.equals("Mixed")){
			try {
				Mixed(algorithm);
			} catch (CloneNotSupportedException e) {
				e.printStackTrace();
			}
		}
		
	}


	public void Aperiodic(String algorithm) throws CloneNotSupportedException{
		int Alg = 0;
		if(algorithm.equals("Jackson (EDD)"))
			Alg	= 0;
		else
			Alg = 1;
		ArrayList<AperiodicTask> ts = new ArrayList<AperiodicTask>();
		for(AperiodicTask t : AperiodicTaskSet){
			ts.add((AperiodicTask) t.clone());
		}
		AperiodicTaskSet apts = new AperiodicTaskSet(ts, ts.size(), Alg);
		tasks = new String[apts.simulationTime];
		for(int i = 0 ; i< apts.simulationTime;i++){
			tasks[i]=apts.simulationScenario[i];
		}
		misses	= apts.deadlineMiss;
		pris	= apts.preemption;
		
		mAdapter.notifyDataSetChanged();
		tv_info.setText(apts.infoString);
	}
	public void Periodic(String algorithm) throws CloneNotSupportedException{
		int Alg = 0;
		if(algorithm.equals("TimeLine"))
			Alg = 0;
		
		if(algorithm.equals("Rate Monotonic"))
			Alg = 1;
		
		if(algorithm.equals("EDF"))
			Alg = 2;
		
		if(algorithm.equals("Deadline Monotonic"))
			Alg = 3;
		
		ArrayList<PeriodicTask> ts = new ArrayList<PeriodicTask>();
		for(PeriodicTask t : PeriodicTaskSet){
			ts.add((PeriodicTask) t.clone());
		}
		PeriodicTaskSet apts = new PeriodicTaskSet(ts, ts.size(), Alg);
		tasks = new String[apts.hyperPeriod];
		for(int i = 0 ; i< apts.hyperPeriod;i++){
			tasks[i]=apts.simulationScenario[i];
		}
		misses	= apts.deadlineMisses;
		pris	= apts.preemption;
		mAdapter.notifyDataSetChanged();
		tv_info.setText(apts.infoString);
	}
	public void Mixed(String algorithm) throws CloneNotSupportedException{
		int Alg = 0;
		if(algorithm.equals("TimeLine"))
			Alg = 0;
		
		if(algorithm.equals("Rate Monotonic"))
			Alg = 1;
		
		if(algorithm.equals("EDF"))
			Alg = 2;
		
		if(algorithm.equals("Deadline Monotonic"))
			Alg = 3;
		
		ArrayList<PeriodicTask> pts = new ArrayList<PeriodicTask>();
		for(PeriodicTask t : PeriodicTaskSet){
			pts.add((PeriodicTask) t.clone());
		}
		
		ArrayList<AperiodicTask> ats = new ArrayList<AperiodicTask>();
		for(AperiodicTask t : AperiodicTaskSet){
			ats.add((AperiodicTask) t.clone());
		}
		MixedTaskSet apts = new MixedTaskSet(pts, ats, Alg);
		tasks = new String[apts.simulationTime];
		for(int i = 0 ; i< apts.simulationTime;i++){
			tasks[i]=apts.simulationScenario[i];
		}
		misses	= apts.deadlineMisses;
		pris	= apts.preemption;
		mAdapter.notifyDataSetChanged();
		tv_info.setText(apts.infoString);
	}

	private BaseAdapter mAdapter = new BaseAdapter() {

		private OnClickListener mOnButtonClicked = new OnClickListener() {

			@Override
			public void onClick(View v) {
				AlertDialog.Builder builder = new AlertDialog.Builder(ChartActivity.this);
				builder.setMessage("hello from " + v);
				builder.setPositiveButton("Cool", null);
				builder.show();

			}
		};

		@Override
		public int getCount() {
			return tasks.length;
		}

		@Override
		public Object getItem(int position) {
			return null;
		}

		@Override
		public long getItemId(int position) {
			return 0;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			View retval = LayoutInflater.from(parent.getContext()).inflate(R.layout.viewitem, null);
			
			//Task t = tasks.get(position);
			
			View color		= (View) retval.findViewById(R.id.color);
			TextView title	= (TextView) retval.findViewById(R.id.title);
			TextView time	= (TextView) retval.findViewById(R.id.time);
			
			View missLine	= (View)retval.findViewById(R.id.miss_line);
			View priLine	= (View)retval.findViewById(R.id.pri_line);
			
			TextView missTxt= (TextView) retval.findViewById(R.id.miss_txt);
			TextView priTxt	= (TextView) retval.findViewById(R.id.pri_txt);
			
			if(misses[position]){
				missLine	.setVisibility(View.VISIBLE);
				missTxt		.setVisibility(View.VISIBLE);
			}else{
				missLine	.setVisibility(View.GONE);
				missTxt		.setVisibility(View.INVISIBLE);
			}
			
			if(pris[position]){
				priLine	.setVisibility(View.VISIBLE);
				priTxt		.setVisibility(View.VISIBLE);
			}else{
				priLine	.setVisibility(View.GONE);
				priTxt		.setVisibility(View.INVISIBLE);
			}
			
			color.setBackgroundColor(GetColor(tasks[position]));
			title.setText(tasks[position]);
			time.setText(position+"");

			return retval;
		}
		private int GetColor(String s){
			for(AperiodicTask p : AperiodicTaskSet){
				if(p.getname().equals(s))
					return p.color;
			}
			for(PeriodicTask p : PeriodicTaskSet){
				if(p.name.equals(s))
					return p.color;
			}
			return Color.WHITE;
		}
	};
}
