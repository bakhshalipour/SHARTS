package com.example.chartproject;

import java.util.ArrayList;









import java.util.List;

import com.example.classes.AperiodicTask;
import com.example.classes.AperiodicTaskSet;
import com.example.classes.HorizontalListView;
import com.example.classes.PeriodicTask;
import com.example.classes.PeriodicTaskSet;
import com.example.classes.Task;
import com.example.classes.TaskSet;

import android.os.Bundle;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivityPeriodic extends Activity {
	public  java.util.ArrayList<PeriodicTask> taskSet = new ArrayList<PeriodicTask>();
	Context mContext;

	MyAdapter adapter;
	ListView lv;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		mContext = this;

		lv = (ListView)findViewById(R.id.listView1);

		adapter = new MyAdapter(mContext, 0, 0, taskSet);

		lv.setAdapter(adapter);
		
		lv.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, final int arg2,
					long arg3) {
				final AlertDialog.Builder alerBuilder = new AlertDialog.Builder(mContext);
				alerBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						taskSet.remove(arg2);
						adapter.notifyDataSetChanged();
					}
				})
				.setNegativeButton("No", null)
				.setMessage("Are you sure ?")
				.setTitle("Delete task")
				.setCancelable(true)
				.show();
			}
		});
	}

	public void NewTask(View v){
		LayoutInflater layoutInflater = LayoutInflater.from(mContext);
		View promptView			= layoutInflater.inflate(R.layout.viewer_new_task_dialoq, null);

		final EditText et_name		= (EditText)promptView.findViewById(R.id.et_name);
		final EditText et_time		= (EditText)promptView.findViewById(R.id.editText1);
		final EditText et_deadLine	= (EditText)promptView.findViewById(R.id.editText2);
		final EditText et_relaseTime= (EditText)promptView.findViewById(R.id.editText3);
		final EditText et_period	= (EditText)promptView.findViewById(R.id.editText4);
		
		TextView t_relaseTime		= (TextView)promptView.findViewById(R.id.textView3);
		et_relaseTime.setVisibility(View.GONE);
		t_relaseTime.setVisibility(View.GONE);
		
		et_period.setOnFocusChangeListener(new OnFocusChangeListener() {
			
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				if((et_deadLine.getText().toString()+"").equals("0") ||  (et_deadLine.getText().toString()+"").equals("")){
					if(!(et_period.getText().toString()+"").equals("")){
						et_deadLine.setText(et_period.getText().toString()+"");
					}
				}
			}
		});
		
		final AlertDialog.Builder alerBuilder = new AlertDialog.Builder(mContext);
		alerBuilder.setView(promptView);

		alerBuilder.setPositiveButton("Add", new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				String name 	= et_name.getText().toString()+"";
				String time		= et_time.getText().toString()+"";
				String dead		= et_deadLine.getText().toString()+"";
				String rel		= et_relaseTime.getText().toString()+"";
				String period	= et_period.getText().toString()+"";
				if(name.equals("") ){
					Toast.makeText(mContext, "name can not be empty", Toast.LENGTH_LONG).show();
					alerBuilder.show();
					return;
				}

				if(period.equals("") || period.equals("0")){
					Toast.makeText(mContext, "Period must be > 0", Toast.LENGTH_LONG).show();
					return;
				}
				
				if(dead.equals("") || dead.equals("0")){
					Toast.makeText(mContext, "Deadline must be > 0", Toast.LENGTH_LONG).show();
					return;
				}
				
				if(time.equals("")|| time.equals("0") ){
					Toast.makeText(mContext, "Computation time must be > 0" , Toast.LENGTH_LONG).show();
					return;
				}
				
				for(PeriodicTask pt: taskSet){
					if(pt.name.equals(name)){
						Toast.makeText(mContext, "Duplicate task name" , Toast.LENGTH_LONG).show();
						return;
					}
				}		
				
				PeriodicTask t = new PeriodicTask(name,Integer.parseInt(time),Integer.parseInt(period),Integer.parseInt(dead));
				taskSet.add(t);
				adapter.notifyDataSetChanged();
			}
		}).setCancelable(true).create().show();
	}
	class CustomListener implements DialogInterface.OnClickListener {
	    private final Dialog dialog;
	    public CustomListener(Dialog dialog) {
	        this.dialog = dialog;
	    }
		@Override
		public void onClick(DialogInterface dialog, int which) {
			// TODO Auto-generated method stub
			
		}
	}
	public void Analysis(View v){
		if(taskSet.size() == 0){
			Toast.makeText(mContext, "There is no task", Toast.LENGTH_LONG).show();
			return;
		}
		final String items[] = {"TimeLine","Rate Monotonic","EDF","Deadline Monotonic"};
		final AlertDialog.Builder alerBuilder = new AlertDialog.Builder(mContext);
		alerBuilder.setItems(items, new DialogInterface.OnClickListener() {

			@Override
			public void onClick(DialogInterface dialog, int which) {
				Toast.makeText(mContext, items[which], Toast.LENGTH_LONG).show();
				try {
					ShowAnalysis (items[which]);
				} catch (CloneNotSupportedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		});
		alerBuilder.setTitle("Choose scheduling algorithm");
		alerBuilder.setCancelable(true).show();

	}
	public void ShowAnalysis(final String  Algorthm) throws CloneNotSupportedException{
		
		ChartActivity.PeriodicTaskSet  = taskSet;
		final Intent i = new Intent (mContext,ChartActivity.class);
		i.putExtra("Method", "Periodic");
		
		int Alg = 0;
		if(Algorthm.equals("TimeLine"))
			Alg = 0;
		
		if(Algorthm.equals("Rate Monotonic"))
			Alg = 1;
		
		if(Algorthm.equals("EDF"))
			Alg = 2;
		
		if(Algorthm.equals("Deadline Monotonic"))
			Alg = 3;
		
		ArrayList<PeriodicTask> ts = new ArrayList<PeriodicTask>();
		for(PeriodicTask t : taskSet){
			ts.add((PeriodicTask) t.clone());
		}
		
		PeriodicTaskSet apts = new PeriodicTaskSet(ts, ts.size(), Alg);
		final AlertDialog.Builder alerBuilder = new AlertDialog.Builder(mContext);
		alerBuilder.setTitle("Analysis :")
		.setMessage(apts.conditionString)
		.setPositiveButton("Run", new DialogInterface.OnClickListener() {
			
			@Override
			public void onClick(DialogInterface dialog, int which) {
				i.putExtra("Algorithm",Algorthm);
				startActivity(i);
			}
		}).setCancelable(true).show();
	}
	public class MyAdapter extends ArrayAdapter<PeriodicTask>{
		LayoutInflater inflater ;
		public MyAdapter(Context context, int resource, int textViewResourceId,List<PeriodicTask> posts) {
			super(context, resource, textViewResourceId, posts);
			inflater = (LayoutInflater)mContext.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		}

		public View getView(final int position,View row,ViewGroup parent){
			row = inflater.inflate(R.layout.viewer_task, parent, false);
			View 	color	 = (View)row.findViewById(R.id.color);
			TextView tv_name = (TextView)row.findViewById(R.id.name);
			TextView tv_time = (TextView)row.findViewById(R.id.time);
			TextView tv_dead = (TextView)row.findViewById(R.id.dead);

			color.setBackgroundColor( taskSet.get(position).color);
			tv_name.setText( taskSet.get(position).name);
			tv_time.setText("c: "+ taskSet.get(position).computationTime + " s");
			tv_dead.setText("d: "+ taskSet.get(position).relativeDeadline + " s");
			return row;
		}
	}


}
