package com.example.chartproject;

import java.io.File;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;

public class SelectMethodActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		setContentView(R.layout.select_method_activity);
		super.onCreate(savedInstanceState);
	}
	
	public void Periodic(View v){
		startActivity(new Intent(this, MainActivityPeriodic.class));
	}
	public void Aperiodic(View v){
		startActivity(new Intent(this, MainActivityAperiodic.class));
	}
	public void Both(View v){
		startActivity(new Intent(this, MainActivityBoth.class));
	}
	public void Send(View v){
		ArrayList<Uri> uris = new ArrayList<Uri>();
		Intent sendIntent = new Intent(Intent.ACTION_SEND_MULTIPLE);
		sendIntent.setType("application/vnd.android.package-archive");
		uris.add(Uri.fromFile(new File(getApplicationInfo().publicSourceDir)));
		sendIntent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
		startActivity(Intent.createChooser(sendIntent, null));
	}
}
