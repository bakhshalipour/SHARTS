package com.example.algorithms;

import java.util.List;
import java.util.Random;

import android.graphics.Color;

import com.example.classes.Algorithm;
import com.example.classes.Task;
import com.example.classes.TaskSet;

public class edf extends Algorithm{

	public edf(TaskSet taskSet) {
		super(taskSet);
	}
	@Override
	public boolean isValid(){
		return (taskSet.GetU()<=1);
	}

	@Override
	public void Perform() {
		int hyper = taskSet.GetHyperperiodTime();

		for(int t=0;t<hyper;t++){

			Task task = GetNearestTask(t);
			if(task!= null){
				task.remainCTime --;
				Task newTask 		= new Task();
				newTask.color		= task.color;
				newTask.name 		= task.name;
				newTask.remainCTime = task.remainCTime;
				result.add(newTask);
			}else{
				Task newTask 		= new Task();
				newTask.color		=  Color.WHITE;
				newTask.name 		= "";
			}
		}
	}
	private Task GetNearestTask(int t){
		int nt = -1;
		Task res = null;
		for(Task task:taskSet.tasks){
			task.Prepare(t);
			if(nt == -1){
				if(task.isRunning(t)){
					nt = task.GetDeadLine(t) - t;
					res= task;
				}
			}

			if(task.isRunning(t)){
				if(task.GetDeadLine(t) - t < nt){
					nt = task.GetDeadLine(t) - t;
					res= task;
				}
			}
		}
		return res;
	}
}
