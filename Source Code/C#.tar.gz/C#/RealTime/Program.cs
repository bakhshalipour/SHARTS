﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTime
{
    class Program
    {
        static void Main(string[] args)
        {
            List<PeriodicTask> myPeriodicTasks = new List<PeriodicTask>();
            List<AperiodicTask> myAperiodicTasks = new List<AperiodicTask>();

            PeriodicTask t0 = new PeriodicTask("tau1", 1, 4, 4);
            PeriodicTask t1 = new PeriodicTask("tau2", 2, 6, 6);
            AperiodicTask t2 = new AperiodicTask("apreq1", 2, 2, 0);
            AperiodicTask t3 = new AperiodicTask("apreq2", 5, 1, 0); 
            AperiodicTask t4 = new AperiodicTask("apreq3", 10, 2, 0);

            myPeriodicTasks.Add(t0);
            myPeriodicTasks.Add(t1);
            myAperiodicTasks.Add(t2);
            myAperiodicTasks.Add(t3);
            myAperiodicTasks.Add(t4);

            MixedTaskSet mts0 = new MixedTaskSet(myPeriodicTasks, myAperiodicTasks, 1);

            mts0.PrintTaskSetInfo();

            Console.ReadLine();
        }
    }
}
