﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTime
{
    class MixedTaskSet
    {
        const int MAX_SIMULATION_TIME = 10000;

        public PeriodicTaskSet myPeriodicTaskSet;
        public List<AperiodicTask> myAperiodicTasks;
        public string[] simulationScenario;
        public int simulationTime;
        public string conditionString;
        public int hyperPeriod;
        public bool[] deadlineMisses;
        public bool[] preemption;
        public int numberOfMisses;
        public float missRate;
        public int numberOfPreemptions;
        public float utilizationFactorOfProcessor;



        public MixedTaskSet(List<PeriodicTask> periodicTasks, List<AperiodicTask> aperiodicTasks, int algorithm)
        {
            this.simulationScenario = new string[MAX_SIMULATION_TIME];
            this.deadlineMisses = new bool[MAX_SIMULATION_TIME];
            this.preemption = new bool[MAX_SIMULATION_TIME];
            myPeriodicTaskSet = new PeriodicTaskSet(periodicTasks, periodicTasks.Count, algorithm);
            this.myAperiodicTasks = aperiodicTasks;
            this.myAperiodicTasks = this.myAperiodicTasks.OrderBy(o => o.releaseTime).ToList();
            this.simulationTime = 2 * myPeriodicTaskSet.hyperPeriod;
            SetSomeExtraInfoAboutPeriodics();
            ExecuteSimulationForPeriodics();        
            ExecuteSimulationForAperiodics();
            ComputeUtilizationFactorOfAllTasks();
        }

        public void SetSomeExtraInfoAboutPeriodics()
        {
            this.conditionString = this.myPeriodicTaskSet.conditionString;
            this.hyperPeriod = this.myPeriodicTaskSet.hyperPeriod;
            this.deadlineMisses = this.myPeriodicTaskSet.deadlineMisses;
            this.preemption = this.myPeriodicTaskSet.preemption;
            this.numberOfMisses = this.myPeriodicTaskSet.numberOfMisses;
            this.missRate = this.myPeriodicTaskSet.missRate;
            this.numberOfPreemptions = this.myPeriodicTaskSet.numberOfPreemptions;
        }

        public void ComputeUtilizationFactorOfAllTasks()
        { 
            int u = 0;

            for (int i = 0; i < this.simulationTime; i++ )
                if (this.simulationScenario[i] != "idle")
                    u++;

            this.utilizationFactorOfProcessor = (float)u / this.simulationTime;
        }

        public void ExecuteSimulationForPeriodics()
        {
            for (int i = 0; i < this.simulationTime; i++)
                this.simulationScenario[i] = this.myPeriodicTaskSet.simulationScenario[i % this.hyperPeriod];
        }

        public void ExecuteSimulationForAperiodics()
        {
            int index = 0;
            int numberOfAperiodicRequests = this.myAperiodicTasks.Count;

            for (int t = 0; t < this.simulationTime; t++)
            {
                if (this.simulationScenario[t] == "idle")
                {
                    index = 0;
                    while (index < numberOfAperiodicRequests && !this.myAperiodicTasks[index].HasNeedToExecute())
                        index++;
                    if (index == numberOfAperiodicRequests)
                        continue;

                    if (this.myAperiodicTasks[index].IsReleased(t))
                    {
                        this.myAperiodicTasks[index].ExecuteOneCycle();
                        this.simulationScenario[t] = this.myAperiodicTasks[index].name;
                    }

                }
            }
        }

        public void PrintTaskSetInfo()
        {
            for (int i = 0; i < this.simulationTime; i++)
                Console.WriteLine(i + "\t" + this.simulationScenario[i] + "\t" + this.deadlineMisses[i] + "\t" + this.preemption[i]);

            Console.WriteLine("MissCounter = " + this.numberOfMisses);
            Console.WriteLine("MissRate = " + this.missRate);
            Console.WriteLine("Preemption = " + this.numberOfPreemptions);
            Console.WriteLine("Utilization Factor of All = " + this.utilizationFactorOfProcessor);
        }
    }
}
