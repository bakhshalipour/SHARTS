﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTime
{
    class PeriodicTaskSet
    {
        const int MAX_SIMULATION_TIME = 10000;

        public List<PeriodicTask> myTaskSet;
        public List<PeriodicTask> sortedMyTaskSetByPeriod;
        public List<PeriodicTask> sortedMyTaskSetByRelativeDeadline;
        public int numberOfTasks;
        public int algorithm;
        public string conditionString;
        public bool isSchedulable;
        public int hyperPeriod;
        public string[] simulationScenario;
        public bool[] deadlineMisses;
        public bool[] preemption;
        public int numberOfMisses;
        public float missRate;
        public int numberOfPreemptions;
        public float utilizationFactorOfProcessor;
        public int minorCycle;
        public int majorCycle;
        public int respect;
        public int numberOfTasksInOneTimeLine;

        public PeriodicTaskSet(List<PeriodicTask> tasks, int numberOfTasks, int algorithm)
        {
            this.myTaskSet = tasks;
            this.numberOfTasks = numberOfTasks;
            this.algorithm = algorithm;

            for (int i = 0; i < myTaskSet.Count; i++)
                this.myTaskSet[i].previousPos = i;

            this.conditionString = String.Empty;
            this.hyperPeriod = this.GetHyperPeriod();
            this.simulationScenario = new string[MAX_SIMULATION_TIME];
            this.deadlineMisses = new bool[MAX_SIMULATION_TIME];
            this.preemption = new bool[MAX_SIMULATION_TIME];
            for (int i = 0; i < MAX_SIMULATION_TIME; i++)
            {
                this.preemption[i] = this.deadlineMisses[i] = false;
                this.simulationScenario[i] = "idle";
            }
            this.numberOfMisses = this.numberOfPreemptions = 0;
            this.missRate = 0;
            this.utilizationFactorOfProcessor = this.GetUtilizationFactorOfProcessor();
            this.majorCycle = this.hyperPeriod;
            this.minorCycle = this.GetMinorCycle();
            this.respect = this.majorCycle / this.minorCycle;

            foreach (var i in this.myTaskSet)
                i.SetInfoOfTaskInHyperPeriod(this.hyperPeriod);

            this.sortedMyTaskSetByPeriod = this.myTaskSet.OrderBy(o => o.period).ToList();
            this.sortedMyTaskSetByRelativeDeadline = this.myTaskSet.OrderBy(o => o.relativeDeadline).ToList();

            this.UpdateCoeffOfTasksForTL(this.myTaskSet);
            this.UpdateCoeffOfTasksForTL(this.sortedMyTaskSetByPeriod);
            this.UpdateCoeffOfTasksForTL(this.sortedMyTaskSetByRelativeDeadline);

            CheckSchedulability();             
            ExecuteSimulation();               
            SetExtraInfo();
        }

        public int GetHyperPeriod()
        {
            int h; 
            bool flag;
            h = this.myTaskSet.Max(o => o.period); 

            while (true)
            {
                flag = true;
                foreach (var i in this.myTaskSet)
                    if (h % i.period != 0)
                        flag = false;
                if (flag)
                    break;
                else
                    h++;
            }

            return h;
        }

        public float GetUtilizationFactorOfProcessor()
        {
            float u = 0;
            foreach (var i in this.myTaskSet)
                u += i.utilizationFactor;
            return u;
        }

        public int GetMinorCycle()
        {
            int g;
            bool flag;
            g = this.myTaskSet.Min(o => o.period);

            while (true)
            {
                flag = true;
                foreach (var i in this.myTaskSet)
                    if (i.period % g != 0)
                        flag = false;
                if (flag)
                    break;
                else
                    g--;
            }

            return g;
        }

        public void CheckSchedulability()
        {
            switch (this.algorithm)
            { 
                case 0:
                    this.isSchedulable = IsSchedulableByTL();
                    break;
                case 1:
                    this.isSchedulable = IsSchedulableByRM();
                    break;
                case 2:
                    this.isSchedulable = IsSchedulableByEDF();
                    break;
                case 3:
                    this.isSchedulable = IsSchedulableByDM();
                    break;
                default:
                    goto case 0;
            }
        }

        public bool IsSchedulableByTL()
        {
            int maximumNumberOfTasksInOneMinorCycle;
            int temp = 0;
            int respect = this.majorCycle / this.minorCycle;
            int requiredComputationTime = 0;
            bool isGuaranteed = true;

            foreach (var i in this.myTaskSet)
                temp += (this.minorCycle * respect) / i.period;

            maximumNumberOfTasksInOneMinorCycle = (int)Math.Ceiling((double)temp/respect);
            int latchedMaximumNumberOfTasksInOneMinorCycle = maximumNumberOfTasksInOneMinorCycle;
            this.numberOfTasksInOneTimeLine = latchedMaximumNumberOfTasksInOneMinorCycle;

            List<PeriodicTask> tempTasks = new List<PeriodicTask>();
            tempTasks = this.myTaskSet.OrderByDescending(o => o.computationTime).ToList();

            while (maximumNumberOfTasksInOneMinorCycle != 0)
            {
                requiredComputationTime += tempTasks[0].computationTime;
                maximumNumberOfTasksInOneMinorCycle--;
                this.conditionString += "+ " + tempTasks[0].computationTime + " ";
                tempTasks.RemoveAt(0);
            }

            if (latchedMaximumNumberOfTasksInOneMinorCycle != 1)
                this.conditionString += "= " + requiredComputationTime;
            this.conditionString += " <= " + this.minorCycle;
            if (conditionString[0] == '+')
                this.conditionString = this.conditionString.Substring(2);

            if (requiredComputationTime <= this.minorCycle)
            {
                this.conditionString += "\tTrue";
                this.conditionString += Environment.NewLine + "TaskSet is schedulable by TimeLine algorithm.";
            }
            else
            {
                this.conditionString += "\tFalse";
                isGuaranteed = false;
                this.conditionString += Environment.NewLine + "TaskSet isn't schedulable by TimeLine algorithm.";
            }

            return isGuaranteed;

        }

        public bool IsSchedulableByRM()
        {
            bool flag = true;
            float uLUB = (float)(this.numberOfTasks * (Math.Pow(2, (float)1 / this.numberOfTasks) - 1));
            this.conditionString += "Checking upper-bound limit: " + Environment.NewLine;
            this.conditionString += "U_LUB = n * (2 ^ (1/n) - 1) -> U_LUB = " + uLUB + Environment.NewLine;
            for (int i = 0; i < this.myTaskSet.Count; i++)
            {
                if (i == 0)
                    this.conditionString += this.myTaskSet[i].utilizationFactor;
                else
                    this.conditionString += " + " + this.myTaskSet[i].utilizationFactor;
            }
            if (this.numberOfTasks != 1)
                this.conditionString += " = " + this.utilizationFactorOfProcessor;
            this.conditionString += " <= " + uLUB + "\t";
            if (this.utilizationFactorOfProcessor <= uLUB)
                this.conditionString += "True";
            else
            {
                this.conditionString += "False";
                flag = false;
            }

            if (flag)
            {
                this.conditionString += Environment.NewLine + "TaskSet is schedulable by RM.";
                return true;
            }
            else
                this.conditionString += Environment.NewLine + "This condition doesn't match. Checking Hyperbolic condition: " + Environment.NewLine;

            flag = true;
            float uHyperbolic = 1;

            for (int i = 0; i < this.myTaskSet.Count; i++)
            {
                if (i == 0)
                    this.conditionString += "(1 + " + this.myTaskSet[i].utilizationFactor + ")";
                else
                    this.conditionString += " * (1 + " + this.myTaskSet[i].utilizationFactor + ")";
                uHyperbolic *= 1 + this.myTaskSet[i].utilizationFactor;
            }
            if (this.numberOfTasks != 1)
                this.conditionString += " = " + uHyperbolic;
            this.conditionString += " <= 2";
            if (uHyperbolic <= 2)
                this.conditionString += "\tTrue" + Environment.NewLine;
            else
            {
                this.conditionString += "\tFalse" + Environment.NewLine;
                flag = false;
            }
            if (flag)
            {
                this.conditionString += "TaskSet is schedulable by RM." + Environment.NewLine;
                return true;
            }
            else
                this.conditionString += "We can not guarantee schedulability by RM." + Environment.NewLine;

            return false;
        }


        public bool IsSchedulableByEDF()
        {
            for (int i = 0; i < this.myTaskSet.Count; i++)
            {
                if (i == 0)
                    this.conditionString += this.myTaskSet[i].utilizationFactor;
                else
                    this.conditionString += " + " + this.myTaskSet[i].utilizationFactor;
            }

            if (this.numberOfTasks != 1)
                this.conditionString += " = " + this.utilizationFactorOfProcessor;
            this.conditionString += " <= 1";
            if (this.utilizationFactorOfProcessor <= 1)
                this.conditionString += "\tTrue" + Environment.NewLine + "TaskSet is schedulable by EDF.";
            else
                this.conditionString += "\tFalse" + Environment.NewLine + "TaskSet isn't schedulable by EDF.";

            return (this.utilizationFactorOfProcessor <= 1);
        }

        public bool IsSchedulableByDM()
        {
            float uDM = 0;
            for (int i = 0; i < this.myTaskSet.Count; i++)
            {
                if (i == 0)
                    this.conditionString += this.myTaskSet[i].utilizationFactorDeadlineMonotonic;
                else
                    this.conditionString += " + " + this.myTaskSet[i].utilizationFactorDeadlineMonotonic;
                uDM += this.myTaskSet[i].utilizationFactorDeadlineMonotonic;
            }

            float uLUBDM = (float)(this.numberOfTasks * (Math.Pow(2, (float)1/this.numberOfTasks) - 1));

            if (this.numberOfTasks != 1)
                this.conditionString += " = " + uDM;
            this.conditionString += " <= " + uLUBDM;

            if (uDM <= uLUBDM)
                this.conditionString += "\tTrue" + Environment.NewLine + "TaskSet is schedulable by Deadline Monotonic";
            else
                this.conditionString += "\tFalse" + Environment.NewLine + "We can not guarantee scheduling under Deadline Monotonic";

            return (uDM <= uLUBDM);
        }

        public void ExecuteSimulation()
        {
            switch (this.algorithm)
            { 
                case 0:
                    ExecuteSimulationByTLAlgorithm();
                    break;
                case 1:
                    ExecuteSimulationByRMAlgorithm();
                    break;
                case 2:
                    ExecuteSimulationByEDFAlgorithm();
                    break;
                case 3:
                    ExecuteSimulationByDMAlgorithm();
                    break;
                default:
                    goto case 0;
            }
        }

        public void ExecuteSimulationByTLAlgorithm()
        {
            List<PeriodicTask> copyOfMyTasks = new List<PeriodicTask>();
            copyOfMyTasks = this.myTaskSet.OrderBy(o => o.coeffOfMinorCycle).ToList();
            int copyOfTasksInOneTimeLine = this.numberOfTasksInOneTimeLine;
            int index = 0;

            for (int t = 0; t < this.majorCycle; t++)
            {
                
                foreach (var i in copyOfMyTasks)
                    i.UpdateRemainingTimeOfExecution(t);

                
                if (t % this.minorCycle == 0)
                {
                    copyOfTasksInOneTimeLine = this.numberOfTasksInOneTimeLine;
                    if (copyOfMyTasks[index].HasNeedToExecute() && t != 0 && this.simulationScenario[t-1] != "idle")
                        this.deadlineMisses[t] = true;
                }

                if (copyOfTasksInOneTimeLine == 0)
                    continue;

                index = 0;
                while (index < this.numberOfTasks && !copyOfMyTasks[index].HasNeedToExecute())
                    index++;
                if (index == this.numberOfTasks)
                    continue;

                copyOfMyTasks[index].ExecuteOneCycle();

                if (!copyOfMyTasks[index].HasNeedToExecute())
                {
                    copyOfMyTasks[index].SetFinishingTime(t + 1);
                    copyOfMyTasks[index].UpdateJobShouldBeDone();
                    copyOfTasksInOneTimeLine--;
                }

                this.simulationScenario[t] = copyOfMyTasks[index].name;

            }
        }

        public void ExecuteSimulationByRMAlgorithm()
        {
            int index;
            bool flag = false;
            for (int t = 0; t < this.hyperPeriod; t++)
            {
                foreach (var i in this.sortedMyTaskSetByPeriod)
                    if (i.MissedDeadline(t))
                        this.deadlineMisses[t] = true;

                foreach (var i in this.sortedMyTaskSetByPeriod)
                    i.UpdateRemainingTimeOfExecution(t);

                index = 0;
                while (index < this.numberOfTasks && !this.sortedMyTaskSetByPeriod[index].HasNeedToExecute())
                    index++;

                if (index == this.numberOfTasks)
                    continue;

                this.sortedMyTaskSetByPeriod[index].ExecuteOneCycle();
                this.simulationScenario[t] = this.sortedMyTaskSetByPeriod[index].name;

                if (t != 0 && !flag && this.simulationScenario[t] != this.simulationScenario[t - 1] && this.simulationScenario[t - 1] != "idle")
                    preemption[t] = true;

                flag = false;
                if (!this.sortedMyTaskSetByPeriod[index].HasNeedToExecute())
                {
                    flag = true;
                    this.sortedMyTaskSetByPeriod[index].SetFinishingTime(t + 1);
                    this.sortedMyTaskSetByPeriod[index].UpdateJobShouldBeDone();
                }

            }
        }

        public void ExecuteSimulationByEDFAlgorithm()
        {
            int index = 0;
            bool flag = false;

            for (int t = 0; t < this.hyperPeriod; t++)
            {
                foreach (var i in this.myTaskSet)
                    if (i.MissedDeadline(t))
                        this.deadlineMisses[t] = true;

                foreach (var i in this.myTaskSet)
                {
                    i.UpdateTimeToDeadline(t);
                    i.UpdateRemainingTimeOfExecution(t);
                }

                this.myTaskSet = this.myTaskSet.OrderByDescending(o => o.timeToDeadline).ToList();
                index = 0;
                while (index < this.numberOfTasks && !this.myTaskSet[index].HasNeedToExecute())
                    index++;
                if (index == this.numberOfTasks)
                    continue;

                this.myTaskSet[index].ExecuteOneCycle();
                this.simulationScenario[t] = this.myTaskSet[index].name;

                if (t != 0 && !flag && this.simulationScenario[t] != this.simulationScenario[t - 1] && this.simulationScenario[t - 1] != "idle")
                    preemption[t] = true;

                flag = false;
                if (!this.myTaskSet[index].HasNeedToExecute())
                {
                    flag = true;
                    this.myTaskSet[index].SetFinishingTime(t + 1);
                    this.myTaskSet[index].UpdateJobShouldBeDone();
                }
                
            }
        }

        public void ExecuteSimulationByDMAlgorithm()
        {
            int index;
            bool flag = false;
            for (int t = 0; t < this.hyperPeriod; t++)
            {
                foreach (var i in this.sortedMyTaskSetByRelativeDeadline)
                    if (i.MissedDeadline(t))
                        this.deadlineMisses[t] = true;

                foreach (var i in this.sortedMyTaskSetByRelativeDeadline)
                    i.UpdateRemainingTimeOfExecution(t);

                index = 0;
                while (index < this.numberOfTasks && !this.sortedMyTaskSetByRelativeDeadline[index].HasNeedToExecute())
                    index++;

                if (index == this.numberOfTasks)
                    continue;

                this.sortedMyTaskSetByRelativeDeadline[index].ExecuteOneCycle();
                this.simulationScenario[t] = this.sortedMyTaskSetByRelativeDeadline[index].name;

                if (t != 0 && !flag && this.simulationScenario[t] != this.simulationScenario[t - 1] && this.simulationScenario[t - 1] != "idle")
                    preemption[t] = true;

                flag = false;
                if (!this.sortedMyTaskSetByRelativeDeadline[index].HasNeedToExecute())
                {
                    flag = true;
                    this.sortedMyTaskSetByRelativeDeadline[index].SetFinishingTime(t + 1);
                    this.sortedMyTaskSetByRelativeDeadline[index].UpdateJobShouldBeDone();
                }

            }
        }

        public void UpdateCoeffOfTasksForTL(List<PeriodicTask> L)
        {
            foreach (var i in L)
                i.coeffOfMinorCycle = i.period / this.minorCycle;
        }

        public void SetExtraInfo()
        {
            foreach (var i in this.deadlineMisses)
                if (i)
                    this.numberOfMisses++;

            foreach (var i in this.preemption)
                if (i)
                    this.numberOfPreemptions++;

            this.missRate = (float)this.numberOfMisses / this.numberOfTasks;
        }

        public void PrintTaskSetInfo()
        {
            Console.WriteLine("MissCounter = " + this.numberOfMisses);
            Console.WriteLine("PreemptionCounter = " + this.numberOfPreemptions);
            Console.WriteLine("MissRate = " + this.missRate);
            
        }

    }
}
