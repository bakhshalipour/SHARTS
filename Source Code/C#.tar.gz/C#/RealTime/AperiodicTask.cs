﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTime
{
    class AperiodicTask
    {
        public string name { get; set; }
        public int releaseTime { get; set; }
        public int computationTime { get; set; }
        public int absoluteDeadline { get; set; }
        public int remainingTimeOfExecution { get; set; }
        public int finishingTime { get; set; }
        public int previousPos { get; set; }

        public AperiodicTask(string name, int releaseTime, int computationTime, int absoluteDeadline)
        {
            this.name = name;
            this.releaseTime = releaseTime;
            this.computationTime = computationTime;
            this.absoluteDeadline = absoluteDeadline;
            this.remainingTimeOfExecution = this.computationTime;
        }

        public void ExecuteOneCycle()
        {
            this.remainingTimeOfExecution--;
        }

        public bool HasNeedToExecute()
        { 
            return (this.remainingTimeOfExecution > 0);
        }

        public bool IsReleased(int t)
        { 
            return (t >= this.releaseTime);
        }

        public bool MissedDeadline(int t)
        {
            if (t == this.absoluteDeadline && this.HasNeedToExecute())
                return true;
            return false;
        }

        public void PrintTaskInfo()
        {
            Console.WriteLine("Task Name: " + this.name);
            Console.WriteLine("Release Time: " + this.releaseTime);
            Console.WriteLine("Computation Time: " + this.computationTime);
            Console.WriteLine("Absolute Deadline: " + this.absoluteDeadline);
            Console.WriteLine("Remaining Time Of Execution: " + this.remainingTimeOfExecution);
            Console.WriteLine("\n");
        }
    }
}
