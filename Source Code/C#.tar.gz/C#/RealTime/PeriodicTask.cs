﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTime
{
    class PeriodicTask
    {
        const int MAX_RELEASES = 10000;

        public string name;
        public int computationTime;
        public int period;
        public int relativeDeadline;
        public float utilizationFactor;
        public float utilizationFactorDeadlineMonotonic;
        public int remainingTimeOfExecution;
        public int[] finishingTime;
        public int previousPos;
        public int coeffOfMinorCycle;
        public int timeToDeadline;

        public int numberOfReleasesInHyperPeriod;
        public int indexOfJobShouldBeDone;
        public int[] taskReleasesInHyperPeriod;
        public int[] taskDeadlinesInHyperPeriod;

        public PeriodicTask(string name, int computationTime, int period, int relativeDeadline)
        {
            this.name = name;
            this.computationTime = computationTime;
            this.period = period;
            this.relativeDeadline = relativeDeadline;
            this.utilizationFactor = (float) this.computationTime / this.period;
            this.utilizationFactorDeadlineMonotonic = (float)this.computationTime / this.relativeDeadline;
            this.taskReleasesInHyperPeriod = new int[MAX_RELEASES];
            this.taskDeadlinesInHyperPeriod = new int[MAX_RELEASES];
            this.finishingTime = new int[MAX_RELEASES];
            this.indexOfJobShouldBeDone = 0;                        
            this.remainingTimeOfExecution = this.computationTime;   
            this.UpdateTimeToDeadline(0);
        }

        public void SetInfoOfTaskInHyperPeriod(int h)
        {
            this.numberOfReleasesInHyperPeriod = h / this.period;

            int index = 0;
            for (int t = 0; t < h; t++)
                if (t % this.period == 0)
                    this.taskReleasesInHyperPeriod[index++] = t;

            for (int i = 0; i < index; i++)
                this.taskDeadlinesInHyperPeriod[i] = this.taskReleasesInHyperPeriod[i] + this.relativeDeadline;
        }

        public void UpdateRemainingTimeOfExecution(int t)
        {
            if (t % this.period == 0 && t != 0)
                this.remainingTimeOfExecution += this.computationTime;
        }

        public void ExecuteOneCycle()
        {
            this.remainingTimeOfExecution--;
        }

        public bool HasNeedToExecute()
        { 
            return (this.remainingTimeOfExecution > 0);
        }

        public int GetThisJobDeadline()
        {
            return this.taskDeadlinesInHyperPeriod[this.indexOfJobShouldBeDone];
        }

        public void UpdateJobShouldBeDone()
        {
            if (this.indexOfJobShouldBeDone < this.numberOfReleasesInHyperPeriod - 1)
                this.indexOfJobShouldBeDone++;
        }

        public bool MissedDeadline(int t)
        {
            if (this.HasNeedToExecute() && t == this.GetThisJobDeadline())
                return true;
            return false;
        }

        public void SetFinishingTime(int t)
        {
            this.finishingTime[this.indexOfJobShouldBeDone] = t;
        }

        public void UpdateTimeToDeadline(int t)
        {
            this.timeToDeadline = t - this.GetThisJobDeadline();
        }

        public void PrintTaskInfo()  
        {
            Console.WriteLine("Task Name: " + this.name);
            Console.WriteLine("Computation Time: " + this.computationTime);
            Console.WriteLine("Period: " + this.period);
            Console.WriteLine("Relative Deadline: " + this.relativeDeadline);
            Console.WriteLine("Utilization Factor: " + this.utilizationFactor);
            Console.WriteLine("Number Of Releases In One HyperPeriod: " + this.numberOfReleasesInHyperPeriod);
            Console.WriteLine("Remaining Time Of Execution: " + this.remainingTimeOfExecution);
            Console.WriteLine("Index Of Job Should Be Done: " + this.indexOfJobShouldBeDone);
            Console.WriteLine("This Job Deadline is: " + this.GetThisJobDeadline());
            Console.WriteLine("Task Releases In One HyperPeriod: ");
            for (int i = 0; i < this.numberOfReleasesInHyperPeriod; i++)
                Console.WriteLine(this.taskReleasesInHyperPeriod[i]);
            Console.WriteLine("Task Deadlines In One HyperPeriod: ");
            for (int i = 0; i < this.numberOfReleasesInHyperPeriod; i++)
                Console.WriteLine(this.taskDeadlinesInHyperPeriod[i]);
        }
    }
}
