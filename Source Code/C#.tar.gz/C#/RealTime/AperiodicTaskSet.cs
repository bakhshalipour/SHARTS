﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RealTime
{
    class AperiodicTaskSet
    {
        const int MAX_SIMULATION_TIME = 10000;

        public List<AperiodicTask> myTaskSet;
        public List<AperiodicTask> sortedMyTaskSet;
        public int numberOfTasks;
        public int algorithm;
        public string conditionString;
        public bool isSchedulable;
        public int simulationTime;
        public string[] simulationScenario;
        public bool[] deadlineMiss;
        public bool[] preemption;
        public int numberOfMisses;
        public float missRate;
        public int numberOfPreemption;
        public float utilizationFactorOfProcessor;
        public int lastComputationTime;
        public int maximumLateness;
        public int maximumTardiness;
        public int maximumLaxity;

        public AperiodicTaskSet(List<AperiodicTask> taskSet, int numberOfTasks, int algorithm)
        {
            this.myTaskSet = taskSet;
            for (int i = 0; i < myTaskSet.Count; i++)
                this.myTaskSet[i].previousPos = i;

            this.sortedMyTaskSet = this.myTaskSet.OrderBy(o => o.absoluteDeadline).ToList();
            this.numberOfTasks = numberOfTasks;
            this.algorithm = algorithm;
            this.conditionString = string.Empty;
            this.simulationTime = myTaskSet.Max(t => t.computationTime) + myTaskSet.Max(t => t.absoluteDeadline);
            this.simulationScenario = new string[MAX_SIMULATION_TIME];
            this.deadlineMiss = new bool[MAX_SIMULATION_TIME];
            this.preemption = new bool[MAX_SIMULATION_TIME];
            for (int i = 0; i < MAX_SIMULATION_TIME; i++)
            {
                this.simulationScenario[i] = "idle";
                this.deadlineMiss[i] = this.preemption[i] = false;
            }
            this.numberOfMisses = this.numberOfPreemption = 0;
            this.missRate = 0;
            this.utilizationFactorOfProcessor = 0;
            this.lastComputationTime = 0;

            CheckSchedulability();             
            ExecuteSimulation();               
            SetExtraInfo();
        }

        public void CheckSchedulability()
        {
            switch (this.algorithm)
            { 
                case 0:
                    this.isSchedulable = IsSchedulableByJacksonAlgorithm();
                    break;
                case 1:
                    this.isSchedulable = IsSchedulableByHornAlgorithm();
                    break;
                default: goto case 0;
            }
        }

        public bool IsSchedulableByJacksonAlgorithm()
        {
            
            bool localIsSchedulable = true;
            int lhs;
            
            for (int i = 0; i < this.numberOfTasks; i++)
            {
                lhs = 0;
                this.conditionString += "Checking Schedulability For Task <" +this.sortedMyTaskSet[i].name + ">: ";
                
                for (int j = 0; j <= i; j++)
                {
                    if (j == 0)
                        this.conditionString += this.sortedMyTaskSet[j].computationTime + " ";
                    else
                        this.conditionString += "+ " + this.sortedMyTaskSet[j].computationTime + " ";

                    lhs += this.sortedMyTaskSet[j].computationTime;
                }

                if (this.numberOfTasks != 1 && i != 0)
                    this.conditionString += " = " + lhs;
                this.conditionString += " <= " + this.sortedMyTaskSet[i].absoluteDeadline + "\t";
                if (lhs <= sortedMyTaskSet[i].absoluteDeadline)
                    conditionString += "True";
                else
                {
                    conditionString += "False";
                    localIsSchedulable = false;
                }

                this.conditionString += Environment.NewLine;
            }
            if (localIsSchedulable)
                this.conditionString += Environment.NewLine + "TaskSet is schedulable by Jackson algorithm.";
            else
                this.conditionString += Environment.NewLine + "TaskSet isn't schedulable by Jackson algorithm.";

            return localIsSchedulable;
        }

        public bool IsSchedulableByHornAlgorithm()
        {
            
            List<AperiodicTask> sortedTasksCopy = this.sortedMyTaskSet;
            bool localIsSchedulable = true;
            int f0 = 0;
            int maximumReleaseTime = 0;

            for (int i = 0; i < sortedTasksCopy.Count; i++)
                if (sortedTasksCopy[i].releaseTime > maximumReleaseTime)
                    maximumReleaseTime = sortedTasksCopy[i].releaseTime;

            for (int t = 0; t <= maximumReleaseTime; t++)
            {
                f0 = f0 > t ? f0 : t;
                for (int i = 0; i < sortedTasksCopy.Count; i++)
                {
                    if (t == sortedTasksCopy[i].releaseTime)
                    {
                        this.conditionString += "Checking Schedulability For Task <" + sortedTasksCopy[i].name + ">: ";
                        this.conditionString += f0 + " + " + sortedTasksCopy[i].computationTime + " = " + (f0 + sortedTasksCopy[i].computationTime) + " <= " + sortedTasksCopy[i].absoluteDeadline + "\t";
                        if (f0 + sortedTasksCopy[i].computationTime <= sortedTasksCopy[i].absoluteDeadline)
                            this.conditionString += "True" + Environment.NewLine;
                        else
                        {
                            this.conditionString += "False" + Environment.NewLine;
                            localIsSchedulable = false;
                        }
                        f0 += sortedTasksCopy[i].computationTime;
                    }
                }
            }

            if (localIsSchedulable)
                this.conditionString += "TaskSet is Schedulable by Horn Algorithm." + Environment.NewLine;
            else
                this.conditionString += "We can not guarantee schedulability of this task set by Horn Algorithm" + Environment.NewLine;

            return localIsSchedulable;
        }

        public void ExecuteSimulation()
        {
            switch (this.algorithm)
            {
                case 0:
                    ExecuteSimulationByJacksonAlgorithm();
                    break;
                case 1:
                    ExecuteSimulationByHornAlgorithm();
                    break;
                default: goto case 0;
            }
        }

        public void ExecuteSimulationByJacksonAlgorithm()
        {

            for (int t = 0; t < this.simulationTime; t++)
            {
                if (this.sortedMyTaskSet.Count == 0)
                    break;
                if (this.sortedMyTaskSet[0].HasNeedToExecute())
                {
                    this.sortedMyTaskSet[0].ExecuteOneCycle();
                    this.simulationScenario[t] = this.sortedMyTaskSet[0].name;
                }

                foreach (var i in sortedMyTaskSet)
                    if (i.MissedDeadline(t + 1))
                        this.deadlineMiss[t + 1] = true;

                if (!this.sortedMyTaskSet[0].HasNeedToExecute())
                {
                    this.myTaskSet[this.sortedMyTaskSet[0].previousPos].finishingTime = t + 1;
                    this.sortedMyTaskSet.RemoveAt(0);
                }
            }
        }

        public void ExecuteSimulationByHornAlgorithm()
        {
            int index;
            bool flag = false;
            int virtualNumberOfTasks = this.numberOfTasks;

            for (int t = 0; t < this.simulationTime; t++)
            {
                if (this.sortedMyTaskSet.Count == 0)
                    break;
                index = 0;
                while (index < virtualNumberOfTasks && t < this.sortedMyTaskSet[index].releaseTime)
                    index++;

                if (index == virtualNumberOfTasks)
                    continue;


                foreach (var i in sortedMyTaskSet)
                    if (i.MissedDeadline(t))
                        this.deadlineMiss[t] = true;

                if (this.sortedMyTaskSet[index].HasNeedToExecute())
                {
                    this.sortedMyTaskSet[index].ExecuteOneCycle();
                    this.simulationScenario[t] = this.sortedMyTaskSet[index].name;
                }

                foreach (var i in sortedMyTaskSet)
                    if (i.MissedDeadline(t + 1))
                        this.deadlineMiss[t + 1] = true;

                if (t != 0)
                {
                    if (!flag && this.simulationScenario[t] != this.simulationScenario[t - 1] && this.simulationScenario[t - 1] != "idle")
                        preemption[t] = true;
                }

                flag = false;
                if (!this.sortedMyTaskSet[index].HasNeedToExecute())
                {
                    flag = true;
                    this.myTaskSet[this.sortedMyTaskSet[index].previousPos].finishingTime = t + 1;
                    this.sortedMyTaskSet.RemoveAt(index);
                    virtualNumberOfTasks--;
                }
            }
        }

        public void SetExtraInfo()
        {
            int u = 0;
            for (int i = MAX_SIMULATION_TIME - 1; i >= 0; i--)
                if (this.simulationScenario[i] != "idle")
                {
                    this.lastComputationTime = i;
                    break;
                }

            for (int i = 0; i <= this.lastComputationTime; i++)
                if (simulationScenario[i] != "idle")
                    u++;

            this.utilizationFactorOfProcessor = (float)u / (lastComputationTime + 1);

            for (int i = 0; i <= this.lastComputationTime; i++)
                if (this.deadlineMiss[i])
                    this.numberOfMisses++;

            for (int i = 0; i <= this.lastComputationTime; i++)
                if (this.preemption[i])
                    this.numberOfPreemption++;

            this.missRate = (float)this.numberOfMisses / this.numberOfTasks;

            
            this.maximumLateness = this.myTaskSet[0].finishingTime - this.myTaskSet[0].absoluteDeadline;
            for (int i = 0; i < this.myTaskSet.Count; i++)
                if (this.myTaskSet[i].finishingTime - this.myTaskSet[i].absoluteDeadline > this.maximumLateness)
                    this.maximumLateness = this.myTaskSet[i].finishingTime - this.myTaskSet[i].absoluteDeadline;

            
            this.maximumTardiness = this.maximumLateness > 0 ? this.maximumLateness : 0;

            
            this.maximumLaxity = this.myTaskSet[0].absoluteDeadline - this.myTaskSet[0].releaseTime - this.myTaskSet[0].computationTime;
            for (int i = 0; i < this.myTaskSet.Count; i++)
                if (this.myTaskSet[i].absoluteDeadline - this.myTaskSet[i].releaseTime - this.myTaskSet[i].computationTime > this.maximumLaxity)
                    this.maximumLaxity = this.myTaskSet[i].absoluteDeadline - this.myTaskSet[i].releaseTime - this.myTaskSet[i].computationTime;

        }

        public void PrintTaskSetInfo()     
        {
            foreach (var i in this.sortedMyTaskSet)
                Console.WriteLine(i.name + "\t" + i.absoluteDeadline);
            Console.WriteLine("Conditions:\n" + this.conditionString);
            Console.WriteLine("Simulation Time:\t" + this.simulationTime);
            for (int i = 0; i < this.simulationTime; i++)
                Console.WriteLine(i + "\t" + this.simulationScenario[i] + "\t" + this.deadlineMiss[i] + "\t" + this.preemption[i]);
            Console.WriteLine("Utilizitaion Factor = " + this.utilizationFactorOfProcessor);
            Console.WriteLine("Number Of Deadline Misses = " + this.numberOfMisses);
            Console.WriteLine("Miss Rate = " + this.missRate);
            Console.WriteLine("Number of Preemptions = " + this.numberOfPreemption);
            Console.WriteLine("Maximum Lateness = " + this.maximumLateness);
            Console.WriteLine("Maximum Tardiness = " + this.maximumTardiness);
            Console.WriteLine("Maximum Laxity = " + this.maximumLaxity);
            Console.WriteLine("Finishing Times: ");
            for (int i = 0; i < this.myTaskSet.Count; i++)
                Console.WriteLine(this.myTaskSet[i].name + "\t" + this.myTaskSet[i].finishingTime);
        }

    }
}
